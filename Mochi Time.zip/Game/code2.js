gdjs.creditsCode = {};
gdjs.creditsCode.GDbkg_95creditsObjects1= [];
gdjs.creditsCode.GDbkg_95creditsObjects2= [];
gdjs.creditsCode.GDbkg_95creditsObjects3= [];
gdjs.creditsCode.GDcredits_950Objects1= [];
gdjs.creditsCode.GDcredits_950Objects2= [];
gdjs.creditsCode.GDcredits_950Objects3= [];
gdjs.creditsCode.GDcredits_951Objects1= [];
gdjs.creditsCode.GDcredits_951Objects2= [];
gdjs.creditsCode.GDcredits_951Objects3= [];
gdjs.creditsCode.GDcredits_952Objects1= [];
gdjs.creditsCode.GDcredits_952Objects2= [];
gdjs.creditsCode.GDcredits_952Objects3= [];
gdjs.creditsCode.GDbtn_95mainmenuObjects1= [];
gdjs.creditsCode.GDbtn_95mainmenuObjects2= [];
gdjs.creditsCode.GDbtn_95mainmenuObjects3= [];
gdjs.creditsCode.GDMochiObjects1= [];
gdjs.creditsCode.GDMochiObjects2= [];
gdjs.creditsCode.GDMochiObjects3= [];
gdjs.creditsCode.GDcredits_953Objects1= [];
gdjs.creditsCode.GDcredits_953Objects2= [];
gdjs.creditsCode.GDcredits_953Objects3= [];
gdjs.creditsCode.GDcredits_955Objects1= [];
gdjs.creditsCode.GDcredits_955Objects2= [];
gdjs.creditsCode.GDcredits_955Objects3= [];

gdjs.creditsCode.conditionTrue_0 = {val:false};
gdjs.creditsCode.condition0IsTrue_0 = {val:false};
gdjs.creditsCode.condition1IsTrue_0 = {val:false};
gdjs.creditsCode.condition2IsTrue_0 = {val:false};
gdjs.creditsCode.condition3IsTrue_0 = {val:false};
gdjs.creditsCode.conditionTrue_1 = {val:false};
gdjs.creditsCode.condition0IsTrue_1 = {val:false};
gdjs.creditsCode.condition1IsTrue_1 = {val:false};
gdjs.creditsCode.condition2IsTrue_1 = {val:false};
gdjs.creditsCode.condition3IsTrue_1 = {val:false};


gdjs.creditsCode.eventsList0 = function(runtimeScene) {

{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.creditsCode.mapOfGDgdjs_46creditsCode_46GDbtn_9595mainmenuObjects1Objects = Hashtable.newFrom({"btn_mainmenu": gdjs.creditsCode.GDbtn_95mainmenuObjects1});
gdjs.creditsCode.eventsList1 = function(runtimeScene) {

{


gdjs.creditsCode.eventsList0(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("bkg_credits"), gdjs.creditsCode.GDbkg_95creditsObjects1);
{for(var i = 0, len = gdjs.creditsCode.GDbkg_95creditsObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDbkg_95creditsObjects1[i].setYOffset(gdjs.creditsCode.GDbkg_95creditsObjects1[i].getYOffset() + ((120 * 1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_mainmenu"), gdjs.creditsCode.GDbtn_95mainmenuObjects1);

gdjs.creditsCode.condition0IsTrue_0.val = false;
gdjs.creditsCode.condition1IsTrue_0.val = false;
gdjs.creditsCode.condition2IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.creditsCode.condition0IsTrue_0.val ) {
{
gdjs.creditsCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.creditsCode.mapOfGDgdjs_46creditsCode_46GDbtn_9595mainmenuObjects1Objects, runtimeScene, true, false);
}if ( gdjs.creditsCode.condition1IsTrue_0.val ) {
{
{gdjs.creditsCode.conditionTrue_1 = gdjs.creditsCode.condition2IsTrue_0;
gdjs.creditsCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12832964);
}
}}
}
if (gdjs.creditsCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main_menu", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


{


gdjs.creditsCode.condition0IsTrue_0.val = false;
{
gdjs.creditsCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.creditsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.creditsCode.GDMochiObjects1);
{for(var i = 0, len = gdjs.creditsCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDMochiObjects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.creditsCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDMochiObjects1[i].flipX(true);
}
}}

}


};

gdjs.creditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.creditsCode.GDbkg_95creditsObjects1.length = 0;
gdjs.creditsCode.GDbkg_95creditsObjects2.length = 0;
gdjs.creditsCode.GDbkg_95creditsObjects3.length = 0;
gdjs.creditsCode.GDcredits_950Objects1.length = 0;
gdjs.creditsCode.GDcredits_950Objects2.length = 0;
gdjs.creditsCode.GDcredits_950Objects3.length = 0;
gdjs.creditsCode.GDcredits_951Objects1.length = 0;
gdjs.creditsCode.GDcredits_951Objects2.length = 0;
gdjs.creditsCode.GDcredits_951Objects3.length = 0;
gdjs.creditsCode.GDcredits_952Objects1.length = 0;
gdjs.creditsCode.GDcredits_952Objects2.length = 0;
gdjs.creditsCode.GDcredits_952Objects3.length = 0;
gdjs.creditsCode.GDbtn_95mainmenuObjects1.length = 0;
gdjs.creditsCode.GDbtn_95mainmenuObjects2.length = 0;
gdjs.creditsCode.GDbtn_95mainmenuObjects3.length = 0;
gdjs.creditsCode.GDMochiObjects1.length = 0;
gdjs.creditsCode.GDMochiObjects2.length = 0;
gdjs.creditsCode.GDMochiObjects3.length = 0;
gdjs.creditsCode.GDcredits_953Objects1.length = 0;
gdjs.creditsCode.GDcredits_953Objects2.length = 0;
gdjs.creditsCode.GDcredits_953Objects3.length = 0;
gdjs.creditsCode.GDcredits_955Objects1.length = 0;
gdjs.creditsCode.GDcredits_955Objects2.length = 0;
gdjs.creditsCode.GDcredits_955Objects3.length = 0;

gdjs.creditsCode.eventsList1(runtimeScene);
return;

}

gdjs['creditsCode'] = gdjs.creditsCode;
