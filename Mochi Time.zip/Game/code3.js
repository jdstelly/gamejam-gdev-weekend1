gdjs.introCode = {};
gdjs.introCode.GDbkg_95introObjects1= [];
gdjs.introCode.GDbkg_95introObjects2= [];
gdjs.introCode.GDbkg_95introObjects3= [];
gdjs.introCode.GDMochiObjects1= [];
gdjs.introCode.GDMochiObjects2= [];
gdjs.introCode.GDMochiObjects3= [];
gdjs.introCode.GDtext_95intro_950Objects1= [];
gdjs.introCode.GDtext_95intro_950Objects2= [];
gdjs.introCode.GDtext_95intro_950Objects3= [];
gdjs.introCode.GDtext_95intro_951Objects1= [];
gdjs.introCode.GDtext_95intro_951Objects2= [];
gdjs.introCode.GDtext_95intro_951Objects3= [];
gdjs.introCode.GDtext_95Mochi_950Objects1= [];
gdjs.introCode.GDtext_95Mochi_950Objects2= [];
gdjs.introCode.GDtext_95Mochi_950Objects3= [];
gdjs.introCode.GDtext_95Mochi_951Objects1= [];
gdjs.introCode.GDtext_95Mochi_951Objects2= [];
gdjs.introCode.GDtext_95Mochi_951Objects3= [];
gdjs.introCode.GDtext_95Mochi_952Objects1= [];
gdjs.introCode.GDtext_95Mochi_952Objects2= [];
gdjs.introCode.GDtext_95Mochi_952Objects3= [];
gdjs.introCode.GDtext_95intro_952Objects1= [];
gdjs.introCode.GDtext_95intro_952Objects2= [];
gdjs.introCode.GDtext_95intro_952Objects3= [];
gdjs.introCode.GDtext_95intro_953Objects1= [];
gdjs.introCode.GDtext_95intro_953Objects2= [];
gdjs.introCode.GDtext_95intro_953Objects3= [];
gdjs.introCode.GDtext_95intro_954Objects1= [];
gdjs.introCode.GDtext_95intro_954Objects2= [];
gdjs.introCode.GDtext_95intro_954Objects3= [];
gdjs.introCode.GDtext_95intro_955Objects1= [];
gdjs.introCode.GDtext_95intro_955Objects2= [];
gdjs.introCode.GDtext_95intro_955Objects3= [];
gdjs.introCode.GDbtn_95start_95gameObjects1= [];
gdjs.introCode.GDbtn_95start_95gameObjects2= [];
gdjs.introCode.GDbtn_95start_95gameObjects3= [];
gdjs.introCode.GDtext_95skipObjects1= [];
gdjs.introCode.GDtext_95skipObjects2= [];
gdjs.introCode.GDtext_95skipObjects3= [];

gdjs.introCode.conditionTrue_0 = {val:false};
gdjs.introCode.condition0IsTrue_0 = {val:false};
gdjs.introCode.condition1IsTrue_0 = {val:false};
gdjs.introCode.condition2IsTrue_0 = {val:false};
gdjs.introCode.conditionTrue_1 = {val:false};
gdjs.introCode.condition0IsTrue_1 = {val:false};
gdjs.introCode.condition1IsTrue_1 = {val:false};
gdjs.introCode.condition2IsTrue_1 = {val:false};


gdjs.introCode.eventsList0 = function(runtimeScene) {

{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.introCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.introCode.eventsList1 = function(runtimeScene) {

{


gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.introCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("btn_start_game"), gdjs.introCode.GDbtn_95start_95gameObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_0"), gdjs.introCode.GDtext_95Mochi_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_1"), gdjs.introCode.GDtext_95Mochi_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_2"), gdjs.introCode.GDtext_95Mochi_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_0"), gdjs.introCode.GDtext_95intro_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_1"), gdjs.introCode.GDtext_95intro_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_2"), gdjs.introCode.GDtext_95intro_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_3"), gdjs.introCode.GDtext_95intro_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_4"), gdjs.introCode.GDtext_95intro_954Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_5"), gdjs.introCode.GDtext_95intro_955Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_skip"), gdjs.introCode.GDtext_95skipObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "intro");
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_950Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_950Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_951Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_951Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_952Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_952Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_953Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_953Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_954Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_954Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_955Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_955Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_950Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_950Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_951Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_951Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_952Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_952Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDbtn_95start_95gameObjects2.length ;i < len;++i) {
    gdjs.introCode.GDbtn_95start_95gameObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95skipObjects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95skipObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].flipX(true);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 1;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12856116);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_intro_0"), gdjs.introCode.GDtext_95intro_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_skip"), gdjs.introCode.GDtext_95skipObjects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95intro_950Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_950Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95skipObjects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95skipObjects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2250, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 3;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12857772);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_1"), gdjs.introCode.GDtext_95intro_951Objects2);
{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_951Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_951Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 5;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12859388);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_0"), gdjs.introCode.GDtext_95Mochi_950Objects2);
{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_950Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_950Objects2[i].setOpacity(255);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 6;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12860580);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_0"), gdjs.introCode.GDtext_95Mochi_950Objects2);
{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_950Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_950Objects2[i].setOpacity(0);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 8;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12861828);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_intro_2"), gdjs.introCode.GDtext_95intro_952Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95intro_952Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 1500, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 14;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12862924);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_1"), gdjs.introCode.GDtext_95Mochi_951Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_951Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_951Objects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setAnimation(1);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 16;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12864180);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_1"), gdjs.introCode.GDtext_95Mochi_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("text_intro_3"), gdjs.introCode.GDtext_95intro_953Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_951Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_951Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95intro_953Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_953Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 1000, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 17;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12865916);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_2"), gdjs.introCode.GDtext_95Mochi_952Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_952Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_952Objects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].setAnimation(2);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 18;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12867172);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.introCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi_2"), gdjs.introCode.GDtext_95Mochi_952Objects2);
{for(var i = 0, len = gdjs.introCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.introCode.GDMochiObjects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 0, "linear", 250, false);
}
}{for(var i = 0, len = gdjs.introCode.GDtext_95Mochi_952Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95Mochi_952Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 0, "linear", 250, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 20;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12868764);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_intro_4"), gdjs.introCode.GDtext_95intro_954Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95intro_954Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_954Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 24;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12869860);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_intro_5"), gdjs.introCode.GDtext_95intro_955Objects2);
{for(var i = 0, len = gdjs.introCode.GDtext_95intro_955Objects2.length ;i < len;++i) {
    gdjs.introCode.GDtext_95intro_955Objects2[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}}

}


{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "intro") > 25;
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12870956);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("btn_start_game"), gdjs.introCode.GDbtn_95start_95gameObjects1);
{for(var i = 0, len = gdjs.introCode.GDbtn_95start_95gameObjects1.length ;i < len;++i) {
    gdjs.introCode.GDbtn_95start_95gameObjects1[i].getBehavior("Tween").addObjectOpacityTween("fadein", 255, "linear", 2000, false);
}
}}

}


};gdjs.introCode.mapOfGDgdjs_46introCode_46GDbtn_9595start_9595gameObjects2Objects = Hashtable.newFrom({"btn_start_game": gdjs.introCode.GDbtn_95start_95gameObjects2});
gdjs.introCode.eventsList2 = function(runtimeScene) {

{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12875228);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


};gdjs.introCode.mapOfGDgdjs_46introCode_46GDbtn_9595start_9595gameObjects1Objects = Hashtable.newFrom({"btn_start_game": gdjs.introCode.GDbtn_95start_95gameObjects1});
gdjs.introCode.eventsList3 = function(runtimeScene) {

{


gdjs.introCode.condition0IsTrue_0.val = false;
gdjs.introCode.condition1IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.introCode.condition0IsTrue_0.val ) {
{
{gdjs.introCode.conditionTrue_1 = gdjs.introCode.condition1IsTrue_0;
gdjs.introCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12872092);
}
}}
if (gdjs.introCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "8_Bit_Menu_-_David_Renda_-_FesliyanStudios.com.mp3", 0, true, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_start_game"), gdjs.introCode.GDbtn_95start_95gameObjects2);

gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.introCode.mapOfGDgdjs_46introCode_46GDbtn_9595start_9595gameObjects2Objects, runtimeScene, true, false);
}if (gdjs.introCode.condition0IsTrue_0.val) {
/* Reuse gdjs.introCode.GDbtn_95start_95gameObjects2 */
{for(var i = 0, len = gdjs.introCode.GDbtn_95start_95gameObjects2.length ;i < len;++i) {
    gdjs.introCode.GDbtn_95start_95gameObjects2[i].setScale(1.1);
}
}
{ //Subevents
gdjs.introCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_start_game"), gdjs.introCode.GDbtn_95start_95gameObjects1);

gdjs.introCode.condition0IsTrue_0.val = false;
{
gdjs.introCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.introCode.mapOfGDgdjs_46introCode_46GDbtn_9595start_9595gameObjects1Objects, runtimeScene, true, true);
}if (gdjs.introCode.condition0IsTrue_0.val) {
/* Reuse gdjs.introCode.GDbtn_95start_95gameObjects1 */
{for(var i = 0, len = gdjs.introCode.GDbtn_95start_95gameObjects1.length ;i < len;++i) {
    gdjs.introCode.GDbtn_95start_95gameObjects1[i].setScale(1.0);
}
}}

}


};gdjs.introCode.eventsList4 = function(runtimeScene) {

{


gdjs.introCode.eventsList0(runtimeScene);
}


{


gdjs.introCode.eventsList1(runtimeScene);
}


{


gdjs.introCode.eventsList3(runtimeScene);
}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("bkg_intro"), gdjs.introCode.GDbkg_95introObjects1);
{for(var i = 0, len = gdjs.introCode.GDbkg_95introObjects1.length ;i < len;++i) {
    gdjs.introCode.GDbkg_95introObjects1[i].setXOffset(gdjs.introCode.GDbkg_95introObjects1[i].getXOffset() + (60 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


};

gdjs.introCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.introCode.GDbkg_95introObjects1.length = 0;
gdjs.introCode.GDbkg_95introObjects2.length = 0;
gdjs.introCode.GDbkg_95introObjects3.length = 0;
gdjs.introCode.GDMochiObjects1.length = 0;
gdjs.introCode.GDMochiObjects2.length = 0;
gdjs.introCode.GDMochiObjects3.length = 0;
gdjs.introCode.GDtext_95intro_950Objects1.length = 0;
gdjs.introCode.GDtext_95intro_950Objects2.length = 0;
gdjs.introCode.GDtext_95intro_950Objects3.length = 0;
gdjs.introCode.GDtext_95intro_951Objects1.length = 0;
gdjs.introCode.GDtext_95intro_951Objects2.length = 0;
gdjs.introCode.GDtext_95intro_951Objects3.length = 0;
gdjs.introCode.GDtext_95Mochi_950Objects1.length = 0;
gdjs.introCode.GDtext_95Mochi_950Objects2.length = 0;
gdjs.introCode.GDtext_95Mochi_950Objects3.length = 0;
gdjs.introCode.GDtext_95Mochi_951Objects1.length = 0;
gdjs.introCode.GDtext_95Mochi_951Objects2.length = 0;
gdjs.introCode.GDtext_95Mochi_951Objects3.length = 0;
gdjs.introCode.GDtext_95Mochi_952Objects1.length = 0;
gdjs.introCode.GDtext_95Mochi_952Objects2.length = 0;
gdjs.introCode.GDtext_95Mochi_952Objects3.length = 0;
gdjs.introCode.GDtext_95intro_952Objects1.length = 0;
gdjs.introCode.GDtext_95intro_952Objects2.length = 0;
gdjs.introCode.GDtext_95intro_952Objects3.length = 0;
gdjs.introCode.GDtext_95intro_953Objects1.length = 0;
gdjs.introCode.GDtext_95intro_953Objects2.length = 0;
gdjs.introCode.GDtext_95intro_953Objects3.length = 0;
gdjs.introCode.GDtext_95intro_954Objects1.length = 0;
gdjs.introCode.GDtext_95intro_954Objects2.length = 0;
gdjs.introCode.GDtext_95intro_954Objects3.length = 0;
gdjs.introCode.GDtext_95intro_955Objects1.length = 0;
gdjs.introCode.GDtext_95intro_955Objects2.length = 0;
gdjs.introCode.GDtext_95intro_955Objects3.length = 0;
gdjs.introCode.GDbtn_95start_95gameObjects1.length = 0;
gdjs.introCode.GDbtn_95start_95gameObjects2.length = 0;
gdjs.introCode.GDbtn_95start_95gameObjects3.length = 0;
gdjs.introCode.GDtext_95skipObjects1.length = 0;
gdjs.introCode.GDtext_95skipObjects2.length = 0;
gdjs.introCode.GDtext_95skipObjects3.length = 0;

gdjs.introCode.eventsList4(runtimeScene);
return;

}

gdjs['introCode'] = gdjs.introCode;
