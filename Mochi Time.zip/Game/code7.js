gdjs.game_95overCode = {};
gdjs.game_95overCode.GDbkg_95gameoverObjects1= [];
gdjs.game_95overCode.GDbkg_95gameoverObjects2= [];
gdjs.game_95overCode.GDbkg_95gameoverObjects3= [];
gdjs.game_95overCode.GDscoreboardObjects1= [];
gdjs.game_95overCode.GDscoreboardObjects2= [];
gdjs.game_95overCode.GDscoreboardObjects3= [];
gdjs.game_95overCode.GDMochiObjects1= [];
gdjs.game_95overCode.GDMochiObjects2= [];
gdjs.game_95overCode.GDMochiObjects3= [];
gdjs.game_95overCode.GDbtn_95mainmenuObjects1= [];
gdjs.game_95overCode.GDbtn_95mainmenuObjects2= [];
gdjs.game_95overCode.GDbtn_95mainmenuObjects3= [];
gdjs.game_95overCode.GDbtn_95playagainObjects1= [];
gdjs.game_95overCode.GDbtn_95playagainObjects2= [];
gdjs.game_95overCode.GDbtn_95playagainObjects3= [];
gdjs.game_95overCode.GDtext_95roundsObjects1= [];
gdjs.game_95overCode.GDtext_95roundsObjects2= [];
gdjs.game_95overCode.GDtext_95roundsObjects3= [];
gdjs.game_95overCode.GDtext_95timeObjects1= [];
gdjs.game_95overCode.GDtext_95timeObjects2= [];
gdjs.game_95overCode.GDtext_95timeObjects3= [];
gdjs.game_95overCode.GDtext_95buildingsObjects1= [];
gdjs.game_95overCode.GDtext_95buildingsObjects2= [];
gdjs.game_95overCode.GDtext_95buildingsObjects3= [];
gdjs.game_95overCode.GDtext_95towelsObjects1= [];
gdjs.game_95overCode.GDtext_95towelsObjects2= [];
gdjs.game_95overCode.GDtext_95towelsObjects3= [];
gdjs.game_95overCode.GDtext_95gameoverObjects1= [];
gdjs.game_95overCode.GDtext_95gameoverObjects2= [];
gdjs.game_95overCode.GDtext_95gameoverObjects3= [];
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects1= [];
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects2= [];
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects3= [];
gdjs.game_95overCode.GDtext_95MochiObjects1= [];
gdjs.game_95overCode.GDtext_95MochiObjects2= [];
gdjs.game_95overCode.GDtext_95MochiObjects3= [];

gdjs.game_95overCode.conditionTrue_0 = {val:false};
gdjs.game_95overCode.condition0IsTrue_0 = {val:false};
gdjs.game_95overCode.condition1IsTrue_0 = {val:false};
gdjs.game_95overCode.condition2IsTrue_0 = {val:false};
gdjs.game_95overCode.condition3IsTrue_0 = {val:false};
gdjs.game_95overCode.conditionTrue_1 = {val:false};
gdjs.game_95overCode.condition0IsTrue_1 = {val:false};
gdjs.game_95overCode.condition1IsTrue_1 = {val:false};
gdjs.game_95overCode.condition2IsTrue_1 = {val:false};
gdjs.game_95overCode.condition3IsTrue_1 = {val:false};


gdjs.game_95overCode.eventsList0 = function(runtimeScene) {

{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595playagainObjects1Objects = Hashtable.newFrom({"btn_playagain": gdjs.game_95overCode.GDbtn_95playagainObjects1});
gdjs.game_95overCode.eventsList1 = function(runtimeScene) {

{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
gdjs.game_95overCode.condition1IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.game_95overCode.condition0IsTrue_0.val ) {
{
{gdjs.game_95overCode.conditionTrue_1 = gdjs.game_95overCode.condition1IsTrue_0;
gdjs.game_95overCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13431684);
}
}}
if (gdjs.game_95overCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(7), true);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


};gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595playagainObjects1Objects = Hashtable.newFrom({"btn_playagain": gdjs.game_95overCode.GDbtn_95playagainObjects1});
gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595mainmenuObjects1Objects = Hashtable.newFrom({"btn_mainmenu": gdjs.game_95overCode.GDbtn_95mainmenuObjects1});
gdjs.game_95overCode.eventsList2 = function(runtimeScene) {

{


gdjs.game_95overCode.eventsList0(runtimeScene);
}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.game_95overCode.GDMochiObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_baseball_hits"), gdjs.game_95overCode.GDtext_95baseball_95hitsObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_buildings"), gdjs.game_95overCode.GDtext_95buildingsObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_rounds"), gdjs.game_95overCode.GDtext_95roundsObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_time"), gdjs.game_95overCode.GDtext_95timeObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_towels"), gdjs.game_95overCode.GDtext_95towelsObjects1);
{for(var i = 0, len = gdjs.game_95overCode.GDtext_95timeObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95timeObjects1[i].setString("Time invested: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("time_played"))) + " seconds");
}
}{for(var i = 0, len = gdjs.game_95overCode.GDtext_95roundsObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95roundsObjects1[i].setString("Rounds played: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.game_95overCode.GDtext_95buildingsObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95buildingsObjects1[i].setString("Buildings destroyed: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("buildings_destroyed"))));
}
}{for(var i = 0, len = gdjs.game_95overCode.GDtext_95towelsObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95towelsObjects1[i].setString("Paper Towels used: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("paper_towels_used"))));
}
}{for(var i = 0, len = gdjs.game_95overCode.GDtext_95baseball_95hitsObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95baseball_95hitsObjects1[i].setString("Home runs made: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("home_runs"))));
}
}{for(var i = 0, len = gdjs.game_95overCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDMochiObjects1[i].setAnimation(1);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "music_mainmenu.wav", 0, false, 100, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("bkg_gameover"), gdjs.game_95overCode.GDbkg_95gameoverObjects1);
{for(var i = 0, len = gdjs.game_95overCode.GDbkg_95gameoverObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDbkg_95gameoverObjects1[i].setYOffset(gdjs.game_95overCode.GDbkg_95gameoverObjects1[i].getYOffset() + ((-(120) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene))));
}
}{for(var i = 0, len = gdjs.game_95overCode.GDbkg_95gameoverObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDbkg_95gameoverObjects1[i].setXOffset(gdjs.game_95overCode.GDbkg_95gameoverObjects1[i].getXOffset() + ((120 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_playagain"), gdjs.game_95overCode.GDbtn_95playagainObjects1);

gdjs.game_95overCode.condition0IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595playagainObjects1Objects, runtimeScene, true, false);
}if (gdjs.game_95overCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.game_95overCode.GDMochiObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi"), gdjs.game_95overCode.GDtext_95MochiObjects1);
{for(var i = 0, len = gdjs.game_95overCode.GDtext_95MochiObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95MochiObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.game_95overCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDMochiObjects1[i].setAnimation(2);
}
}
{ //Subevents
gdjs.game_95overCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_playagain"), gdjs.game_95overCode.GDbtn_95playagainObjects1);

gdjs.game_95overCode.condition0IsTrue_0.val = false;
gdjs.game_95overCode.condition1IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595playagainObjects1Objects, runtimeScene, true, true);
}if ( gdjs.game_95overCode.condition0IsTrue_0.val ) {
{
{gdjs.game_95overCode.conditionTrue_1 = gdjs.game_95overCode.condition1IsTrue_0;
gdjs.game_95overCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13491836);
}
}}
if (gdjs.game_95overCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.game_95overCode.GDMochiObjects1);
gdjs.copyArray(runtimeScene.getObjects("text_Mochi"), gdjs.game_95overCode.GDtext_95MochiObjects1);
{for(var i = 0, len = gdjs.game_95overCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDMochiObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.game_95overCode.GDtext_95MochiObjects1.length ;i < len;++i) {
    gdjs.game_95overCode.GDtext_95MochiObjects1[i].setOpacity(255);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_mainmenu"), gdjs.game_95overCode.GDbtn_95mainmenuObjects1);

gdjs.game_95overCode.condition0IsTrue_0.val = false;
gdjs.game_95overCode.condition1IsTrue_0.val = false;
gdjs.game_95overCode.condition2IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.game_95overCode.mapOfGDgdjs_46game_9595overCode_46GDbtn_9595mainmenuObjects1Objects, runtimeScene, true, false);
}if ( gdjs.game_95overCode.condition0IsTrue_0.val ) {
{
gdjs.game_95overCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.game_95overCode.condition1IsTrue_0.val ) {
{
{gdjs.game_95overCode.conditionTrue_1 = gdjs.game_95overCode.condition2IsTrue_0;
gdjs.game_95overCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13299828);
}
}}
}
if (gdjs.game_95overCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main_menu", false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(7), true);
}}

}


{


gdjs.game_95overCode.condition0IsTrue_0.val = false;
gdjs.game_95overCode.condition1IsTrue_0.val = false;
{
gdjs.game_95overCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(7), true);
}if ( gdjs.game_95overCode.condition0IsTrue_0.val ) {
{
{gdjs.game_95overCode.conditionTrue_1 = gdjs.game_95overCode.condition1IsTrue_0;
gdjs.game_95overCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13474756);
}
}}
if (gdjs.game_95overCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(5);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().get("max_game_timer").setNumber(10);
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("buildings_destroyed").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("paper_towels_used").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("home_runs").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(5);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(7), false);
}}

}


};

gdjs.game_95overCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.game_95overCode.GDbkg_95gameoverObjects1.length = 0;
gdjs.game_95overCode.GDbkg_95gameoverObjects2.length = 0;
gdjs.game_95overCode.GDbkg_95gameoverObjects3.length = 0;
gdjs.game_95overCode.GDscoreboardObjects1.length = 0;
gdjs.game_95overCode.GDscoreboardObjects2.length = 0;
gdjs.game_95overCode.GDscoreboardObjects3.length = 0;
gdjs.game_95overCode.GDMochiObjects1.length = 0;
gdjs.game_95overCode.GDMochiObjects2.length = 0;
gdjs.game_95overCode.GDMochiObjects3.length = 0;
gdjs.game_95overCode.GDbtn_95mainmenuObjects1.length = 0;
gdjs.game_95overCode.GDbtn_95mainmenuObjects2.length = 0;
gdjs.game_95overCode.GDbtn_95mainmenuObjects3.length = 0;
gdjs.game_95overCode.GDbtn_95playagainObjects1.length = 0;
gdjs.game_95overCode.GDbtn_95playagainObjects2.length = 0;
gdjs.game_95overCode.GDbtn_95playagainObjects3.length = 0;
gdjs.game_95overCode.GDtext_95roundsObjects1.length = 0;
gdjs.game_95overCode.GDtext_95roundsObjects2.length = 0;
gdjs.game_95overCode.GDtext_95roundsObjects3.length = 0;
gdjs.game_95overCode.GDtext_95timeObjects1.length = 0;
gdjs.game_95overCode.GDtext_95timeObjects2.length = 0;
gdjs.game_95overCode.GDtext_95timeObjects3.length = 0;
gdjs.game_95overCode.GDtext_95buildingsObjects1.length = 0;
gdjs.game_95overCode.GDtext_95buildingsObjects2.length = 0;
gdjs.game_95overCode.GDtext_95buildingsObjects3.length = 0;
gdjs.game_95overCode.GDtext_95towelsObjects1.length = 0;
gdjs.game_95overCode.GDtext_95towelsObjects2.length = 0;
gdjs.game_95overCode.GDtext_95towelsObjects3.length = 0;
gdjs.game_95overCode.GDtext_95gameoverObjects1.length = 0;
gdjs.game_95overCode.GDtext_95gameoverObjects2.length = 0;
gdjs.game_95overCode.GDtext_95gameoverObjects3.length = 0;
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects1.length = 0;
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects2.length = 0;
gdjs.game_95overCode.GDtext_95baseball_95hitsObjects3.length = 0;
gdjs.game_95overCode.GDtext_95MochiObjects1.length = 0;
gdjs.game_95overCode.GDtext_95MochiObjects2.length = 0;
gdjs.game_95overCode.GDtext_95MochiObjects3.length = 0;

gdjs.game_95overCode.eventsList2(runtimeScene);
return;

}

gdjs['game_95overCode'] = gdjs.game_95overCode;
