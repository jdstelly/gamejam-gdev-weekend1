gdjs.main_95menuCode = {};
gdjs.main_95menuCode.GDbkg_95menuObjects1= [];
gdjs.main_95menuCode.GDbkg_95menuObjects2= [];
gdjs.main_95menuCode.GDbkg_95menuObjects3= [];
gdjs.main_95menuCode.GDbkg_95menuObjects4= [];
gdjs.main_95menuCode.GDMochiObjects1= [];
gdjs.main_95menuCode.GDMochiObjects2= [];
gdjs.main_95menuCode.GDMochiObjects3= [];
gdjs.main_95menuCode.GDMochiObjects4= [];
gdjs.main_95menuCode.GDtitleObjects1= [];
gdjs.main_95menuCode.GDtitleObjects2= [];
gdjs.main_95menuCode.GDtitleObjects3= [];
gdjs.main_95menuCode.GDtitleObjects4= [];
gdjs.main_95menuCode.GDbtn_95playObjects1= [];
gdjs.main_95menuCode.GDbtn_95playObjects2= [];
gdjs.main_95menuCode.GDbtn_95playObjects3= [];
gdjs.main_95menuCode.GDbtn_95playObjects4= [];
gdjs.main_95menuCode.GDbtn_95flavorObjects1= [];
gdjs.main_95menuCode.GDbtn_95flavorObjects2= [];
gdjs.main_95menuCode.GDbtn_95flavorObjects3= [];
gdjs.main_95menuCode.GDbtn_95flavorObjects4= [];
gdjs.main_95menuCode.GDbtn_95creditsObjects1= [];
gdjs.main_95menuCode.GDbtn_95creditsObjects2= [];
gdjs.main_95menuCode.GDbtn_95creditsObjects3= [];
gdjs.main_95menuCode.GDbtn_95creditsObjects4= [];
gdjs.main_95menuCode.GDbtn_95supportObjects1= [];
gdjs.main_95menuCode.GDbtn_95supportObjects2= [];
gdjs.main_95menuCode.GDbtn_95supportObjects3= [];
gdjs.main_95menuCode.GDbtn_95supportObjects4= [];
gdjs.main_95menuCode.GDtext_95supportObjects1= [];
gdjs.main_95menuCode.GDtext_95supportObjects2= [];
gdjs.main_95menuCode.GDtext_95supportObjects3= [];
gdjs.main_95menuCode.GDtext_95supportObjects4= [];
gdjs.main_95menuCode.GDMochiconObjects1= [];
gdjs.main_95menuCode.GDMochiconObjects2= [];
gdjs.main_95menuCode.GDMochiconObjects3= [];
gdjs.main_95menuCode.GDMochiconObjects4= [];
gdjs.main_95menuCode.GDtext_95flavorObjects1= [];
gdjs.main_95menuCode.GDtext_95flavorObjects2= [];
gdjs.main_95menuCode.GDtext_95flavorObjects3= [];
gdjs.main_95menuCode.GDtext_95flavorObjects4= [];
gdjs.main_95menuCode.GDflavor_95blockerObjects1= [];
gdjs.main_95menuCode.GDflavor_95blockerObjects2= [];
gdjs.main_95menuCode.GDflavor_95blockerObjects3= [];
gdjs.main_95menuCode.GDflavor_95blockerObjects4= [];

gdjs.main_95menuCode.conditionTrue_0 = {val:false};
gdjs.main_95menuCode.condition0IsTrue_0 = {val:false};
gdjs.main_95menuCode.condition1IsTrue_0 = {val:false};
gdjs.main_95menuCode.condition2IsTrue_0 = {val:false};
gdjs.main_95menuCode.conditionTrue_1 = {val:false};
gdjs.main_95menuCode.condition0IsTrue_1 = {val:false};
gdjs.main_95menuCode.condition1IsTrue_1 = {val:false};
gdjs.main_95menuCode.condition2IsTrue_1 = {val:false};


gdjs.main_95menuCode.eventsList0 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.main_95menuCode.eventsList1 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 0));
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "music_mainmenu.wav", 0, true, 100, 1);
}}

}


};gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595playObjects2Objects = Hashtable.newFrom({"btn_play": gdjs.main_95menuCode.GDbtn_95playObjects2});
gdjs.main_95menuCode.eventsList2 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
{gdjs.main_95menuCode.conditionTrue_1 = gdjs.main_95menuCode.condition1IsTrue_0;
gdjs.main_95menuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12695948);
}
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "intro", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


};gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595flavorObjects2Objects = Hashtable.newFrom({"btn_flavor": gdjs.main_95menuCode.GDbtn_95flavorObjects2});
gdjs.main_95menuCode.eventsList3 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
gdjs.main_95menuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("strawberry");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects3.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects3[i].setString("STRAWBERRY");
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
gdjs.main_95menuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("blueberry");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects3.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects3[i].setString(" BLUEBERRY");
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
gdjs.main_95menuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("banana");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects3.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects3[i].setString("  BANANA");
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
gdjs.main_95menuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("kiwi");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects3.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects3[i].setString("    KIWI");
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
gdjs.main_95menuCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("vanilla");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects3.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects3[i].setString("  VANILLA");
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flavor_blocker"), gdjs.main_95menuCode.GDflavor_95blockerObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "flavor_chosen.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.main_95menuCode.GDflavor_95blockerObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDflavor_95blockerObjects2[i].setOpacity(120);
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects2[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects2[i].getBehavior("Tween").addObjectOpacityTween("fade0", 0, "linear", 2000, false);
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDflavor_95blockerObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDflavor_95blockerObjects2[i].getBehavior("Tween").addObjectOpacityTween("fade1", 0, "linear", 1500, false);
}
}}

}


};gdjs.main_95menuCode.eventsList4 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
{gdjs.main_95menuCode.conditionTrue_1 = gdjs.main_95menuCode.condition1IsTrue_0;
gdjs.main_95menuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12697852);
}
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.main_95menuCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595creditsObjects2Objects = Hashtable.newFrom({"btn_credits": gdjs.main_95menuCode.GDbtn_95creditsObjects2});
gdjs.main_95menuCode.eventsList5 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
{gdjs.main_95menuCode.conditionTrue_1 = gdjs.main_95menuCode.condition1IsTrue_0;
gdjs.main_95menuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12706228);
}
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "credits", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


};gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595supportObjects2Objects = Hashtable.newFrom({"btn_support": gdjs.main_95menuCode.GDbtn_95supportObjects2});
gdjs.main_95menuCode.eventsList6 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
{gdjs.main_95menuCode.conditionTrue_1 = gdjs.main_95menuCode.condition1IsTrue_0;
gdjs.main_95menuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12709364);
}
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.main_95menuCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_support"), gdjs.main_95menuCode.GDtext_95supportObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "support_timer");
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95supportObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95supportObjects2[i].setLayer("");
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDMochiObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95supportObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95supportObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(gdjs.randomInRange(0, 5))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "buttonPress0.wav", false, 100, 1);
}}

}


};gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595playObjects2Objects = Hashtable.newFrom({"btn_play": gdjs.main_95menuCode.GDbtn_95playObjects2});
gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595flavorObjects2Objects = Hashtable.newFrom({"btn_flavor": gdjs.main_95menuCode.GDbtn_95flavorObjects2});
gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595creditsObjects2Objects = Hashtable.newFrom({"btn_credits": gdjs.main_95menuCode.GDbtn_95creditsObjects2});
gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595supportObjects1Objects = Hashtable.newFrom({"btn_support": gdjs.main_95menuCode.GDbtn_95supportObjects1});
gdjs.main_95menuCode.eventsList7 = function(runtimeScene) {

{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flavor_blocker"), gdjs.main_95menuCode.GDflavor_95blockerObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_flavor"), gdjs.main_95menuCode.GDtext_95flavorObjects2);
{for(var i = 0, len = gdjs.main_95menuCode.GDflavor_95blockerObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDflavor_95blockerObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95flavorObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95flavorObjects2[i].setOpacity(0);
}
}
{ //Subevents
gdjs.main_95menuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("bkg_menu"), gdjs.main_95menuCode.GDbkg_95menuObjects2);
{for(var i = 0, len = gdjs.main_95menuCode.GDbkg_95menuObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbkg_95menuObjects2[i].setXOffset(gdjs.main_95menuCode.GDbkg_95menuObjects2[i].getXOffset() + (-(60) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


gdjs.main_95menuCode.condition0IsTrue_0.val = false;
gdjs.main_95menuCode.condition1IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "support_timer") > 2;
}if ( gdjs.main_95menuCode.condition0IsTrue_0.val ) {
{
{gdjs.main_95menuCode.conditionTrue_1 = gdjs.main_95menuCode.condition1IsTrue_0;
gdjs.main_95menuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12693740);
}
}}
if (gdjs.main_95menuCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.main_95menuCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_support"), gdjs.main_95menuCode.GDtext_95supportObjects2);
{for(var i = 0, len = gdjs.main_95menuCode.GDtext_95supportObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDtext_95supportObjects2[i].setLayer("Hidden");
}
}{for(var i = 0, len = gdjs.main_95menuCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDMochiObjects2[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_play"), gdjs.main_95menuCode.GDbtn_95playObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595playObjects2Objects, runtimeScene, true, false);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95playObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95playObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95playObjects2[i].setScale(1.1);
}
}
{ //Subevents
gdjs.main_95menuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("btn_flavor"), gdjs.main_95menuCode.GDbtn_95flavorObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595flavorObjects2Objects, runtimeScene, true, false);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95flavorObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95flavorObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95flavorObjects2[i].setScale(1.1);
}
}
{ //Subevents
gdjs.main_95menuCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_credits"), gdjs.main_95menuCode.GDbtn_95creditsObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595creditsObjects2Objects, runtimeScene, true, false);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95creditsObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95creditsObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95creditsObjects2[i].setScale(1.1);
}
}
{ //Subevents
gdjs.main_95menuCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("btn_support"), gdjs.main_95menuCode.GDbtn_95supportObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595supportObjects2Objects, runtimeScene, true, false);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95supportObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95supportObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95supportObjects2[i].setScale(1.1);
}
}
{ //Subevents
gdjs.main_95menuCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_play"), gdjs.main_95menuCode.GDbtn_95playObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595playObjects2Objects, runtimeScene, true, true);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95playObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95playObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95playObjects2[i].setScale(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_flavor"), gdjs.main_95menuCode.GDbtn_95flavorObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595flavorObjects2Objects, runtimeScene, true, true);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95flavorObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95flavorObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95flavorObjects2[i].setScale(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_credits"), gdjs.main_95menuCode.GDbtn_95creditsObjects2);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595creditsObjects2Objects, runtimeScene, true, true);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95creditsObjects2 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95creditsObjects2.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95creditsObjects2[i].setScale(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("btn_support"), gdjs.main_95menuCode.GDbtn_95supportObjects1);

gdjs.main_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.main_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.main_95menuCode.mapOfGDgdjs_46main_9595menuCode_46GDbtn_9595supportObjects1Objects, runtimeScene, true, true);
}if (gdjs.main_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.main_95menuCode.GDbtn_95supportObjects1 */
{for(var i = 0, len = gdjs.main_95menuCode.GDbtn_95supportObjects1.length ;i < len;++i) {
    gdjs.main_95menuCode.GDbtn_95supportObjects1[i].setScale(1);
}
}}

}


};gdjs.main_95menuCode.eventsList8 = function(runtimeScene) {

{


gdjs.main_95menuCode.eventsList0(runtimeScene);
}


{


gdjs.main_95menuCode.eventsList7(runtimeScene);
}


};

gdjs.main_95menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.main_95menuCode.GDbkg_95menuObjects1.length = 0;
gdjs.main_95menuCode.GDbkg_95menuObjects2.length = 0;
gdjs.main_95menuCode.GDbkg_95menuObjects3.length = 0;
gdjs.main_95menuCode.GDbkg_95menuObjects4.length = 0;
gdjs.main_95menuCode.GDMochiObjects1.length = 0;
gdjs.main_95menuCode.GDMochiObjects2.length = 0;
gdjs.main_95menuCode.GDMochiObjects3.length = 0;
gdjs.main_95menuCode.GDMochiObjects4.length = 0;
gdjs.main_95menuCode.GDtitleObjects1.length = 0;
gdjs.main_95menuCode.GDtitleObjects2.length = 0;
gdjs.main_95menuCode.GDtitleObjects3.length = 0;
gdjs.main_95menuCode.GDtitleObjects4.length = 0;
gdjs.main_95menuCode.GDbtn_95playObjects1.length = 0;
gdjs.main_95menuCode.GDbtn_95playObjects2.length = 0;
gdjs.main_95menuCode.GDbtn_95playObjects3.length = 0;
gdjs.main_95menuCode.GDbtn_95playObjects4.length = 0;
gdjs.main_95menuCode.GDbtn_95flavorObjects1.length = 0;
gdjs.main_95menuCode.GDbtn_95flavorObjects2.length = 0;
gdjs.main_95menuCode.GDbtn_95flavorObjects3.length = 0;
gdjs.main_95menuCode.GDbtn_95flavorObjects4.length = 0;
gdjs.main_95menuCode.GDbtn_95creditsObjects1.length = 0;
gdjs.main_95menuCode.GDbtn_95creditsObjects2.length = 0;
gdjs.main_95menuCode.GDbtn_95creditsObjects3.length = 0;
gdjs.main_95menuCode.GDbtn_95creditsObjects4.length = 0;
gdjs.main_95menuCode.GDbtn_95supportObjects1.length = 0;
gdjs.main_95menuCode.GDbtn_95supportObjects2.length = 0;
gdjs.main_95menuCode.GDbtn_95supportObjects3.length = 0;
gdjs.main_95menuCode.GDbtn_95supportObjects4.length = 0;
gdjs.main_95menuCode.GDtext_95supportObjects1.length = 0;
gdjs.main_95menuCode.GDtext_95supportObjects2.length = 0;
gdjs.main_95menuCode.GDtext_95supportObjects3.length = 0;
gdjs.main_95menuCode.GDtext_95supportObjects4.length = 0;
gdjs.main_95menuCode.GDMochiconObjects1.length = 0;
gdjs.main_95menuCode.GDMochiconObjects2.length = 0;
gdjs.main_95menuCode.GDMochiconObjects3.length = 0;
gdjs.main_95menuCode.GDMochiconObjects4.length = 0;
gdjs.main_95menuCode.GDtext_95flavorObjects1.length = 0;
gdjs.main_95menuCode.GDtext_95flavorObjects2.length = 0;
gdjs.main_95menuCode.GDtext_95flavorObjects3.length = 0;
gdjs.main_95menuCode.GDtext_95flavorObjects4.length = 0;
gdjs.main_95menuCode.GDflavor_95blockerObjects1.length = 0;
gdjs.main_95menuCode.GDflavor_95blockerObjects2.length = 0;
gdjs.main_95menuCode.GDflavor_95blockerObjects3.length = 0;
gdjs.main_95menuCode.GDflavor_95blockerObjects4.length = 0;

gdjs.main_95menuCode.eventsList8(runtimeScene);
return;

}

gdjs['main_95menuCode'] = gdjs.main_95menuCode;
