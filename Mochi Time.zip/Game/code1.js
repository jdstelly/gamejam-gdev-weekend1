gdjs.transitionCode = {};
gdjs.transitionCode.GDbkg_95transitionObjects1= [];
gdjs.transitionCode.GDbkg_95transitionObjects2= [];
gdjs.transitionCode.GDbkg_95transitionObjects3= [];
gdjs.transitionCode.GDbkg_95transitionObjects4= [];
gdjs.transitionCode.GDtext_95transitionObjects1= [];
gdjs.transitionCode.GDtext_95transitionObjects2= [];
gdjs.transitionCode.GDtext_95transitionObjects3= [];
gdjs.transitionCode.GDtext_95transitionObjects4= [];
gdjs.transitionCode.GDtext_95debug_95tempoObjects1= [];
gdjs.transitionCode.GDtext_95debug_95tempoObjects2= [];
gdjs.transitionCode.GDtext_95debug_95tempoObjects3= [];
gdjs.transitionCode.GDtext_95debug_95tempoObjects4= [];
gdjs.transitionCode.GDMochiObjects1= [];
gdjs.transitionCode.GDMochiObjects2= [];
gdjs.transitionCode.GDMochiObjects3= [];
gdjs.transitionCode.GDMochiObjects4= [];
gdjs.transitionCode.GDtext_95roundObjects1= [];
gdjs.transitionCode.GDtext_95roundObjects2= [];
gdjs.transitionCode.GDtext_95roundObjects3= [];
gdjs.transitionCode.GDtext_95roundObjects4= [];
gdjs.transitionCode.GDtext_95timerObjects1= [];
gdjs.transitionCode.GDtext_95timerObjects2= [];
gdjs.transitionCode.GDtext_95timerObjects3= [];
gdjs.transitionCode.GDtext_95timerObjects4= [];

gdjs.transitionCode.conditionTrue_0 = {val:false};
gdjs.transitionCode.condition0IsTrue_0 = {val:false};
gdjs.transitionCode.condition1IsTrue_0 = {val:false};
gdjs.transitionCode.condition2IsTrue_0 = {val:false};
gdjs.transitionCode.condition3IsTrue_0 = {val:false};
gdjs.transitionCode.conditionTrue_1 = {val:false};
gdjs.transitionCode.condition0IsTrue_1 = {val:false};
gdjs.transitionCode.condition1IsTrue_1 = {val:false};
gdjs.transitionCode.condition2IsTrue_1 = {val:false};
gdjs.transitionCode.condition3IsTrue_1 = {val:false};


gdjs.transitionCode.eventsList0 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.transitionCode.eventsList1 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 0);
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "8_Bit_Menu_-_David_Renda_-_FesliyanStudios.com.mp3", 0, true, 100, 1);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "good0.wav", false, 100, 1);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "bad0.wav", false, 33, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}}

}


{


{
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 0;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) <= 10;
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) * 0.1));
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 10;
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(10);
}}

}


{



}


{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(6 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 6));
}}

}


};gdjs.transitionCode.eventsList2 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.transitionCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.transitionCode.eventsList3 = function(runtimeScene) {

{



}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.transitionCode.GDMochiObjects2, gdjs.transitionCode.GDMochiObjects3);

{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects3[i].setScale(1.75);
}
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) >= 0;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) < 3;
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_transition"), gdjs.transitionCode.GDtext_95transitionObjects3);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95transitionObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95transitionObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(gdjs.randomInRange(0, 2))));
}
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) >= 3;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) < 7;
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_transition"), gdjs.transitionCode.GDtext_95transitionObjects3);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95transitionObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95transitionObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(gdjs.randomInRange(3, 5))));
}
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) >= 7;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 9;
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.transitionCode.GDMochiObjects2, gdjs.transitionCode.GDMochiObjects3);

gdjs.copyArray(runtimeScene.getObjects("text_transition"), gdjs.transitionCode.GDtext_95transitionObjects3);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95transitionObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95transitionObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(gdjs.randomInRange(6, 8))));
}
}{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects3[i].setAnimationSpeedScale(3.0);
}
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 9;
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.transitionCode.GDMochiObjects2, gdjs.transitionCode.GDMochiObjects3);

gdjs.copyArray(runtimeScene.getObjects("text_transition"), gdjs.transitionCode.GDtext_95transitionObjects3);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95transitionObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95transitionObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(gdjs.randomInRange(6, 8))));
}
}{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects3[i].setAnimationSpeedScale(3.5);
}
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) >= 15;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}
if (gdjs.transitionCode.condition1IsTrue_0.val) {
/* Reuse gdjs.transitionCode.GDMochiObjects2 */
gdjs.copyArray(runtimeScene.getObjects("text_transition"), gdjs.transitionCode.GDtext_95transitionObjects2);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95transitionObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95transitionObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1).getChild(9)));
}
}{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects2[i].setAnimationSpeedScale(7.5);
}
}}

}


};gdjs.transitionCode.eventsList4 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "transition") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0));
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
/* Reuse gdjs.transitionCode.GDtext_95debug_95tempoObjects2 */
{for(var i = 0, len = gdjs.transitionCode.GDtext_95debug_95tempoObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95debug_95tempoObjects2[i].setString("GAME START! - " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild(gdjs.randomInRange(0, 2))));
}
}}

}


};gdjs.transitionCode.eventsList5 = function(runtimeScene) {

{



}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.transitionCode.GDMochiObjects2);
{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.transitionCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDMochiObjects2[i].setScale(1.75);
}
}
{ //Subevents
gdjs.transitionCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("bkg_transition"), gdjs.transitionCode.GDbkg_95transitionObjects2);
{for(var i = 0, len = gdjs.transitionCode.GDbkg_95transitionObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDbkg_95transitionObjects2[i].setXOffset(gdjs.transitionCode.GDbkg_95transitionObjects2[i].getXOffset() + ((120 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{



}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), true);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_debug_tempo"), gdjs.transitionCode.GDtext_95debug_95tempoObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_timer"), gdjs.transitionCode.GDtext_95timerObjects2);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95debug_95tempoObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95debug_95tempoObjects2[i].setString("TEMPO: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.transitionCode.GDtext_95timerObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95timerObjects2[i].setString("transition timer: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.trunc(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "transition"))));
}
}
{ //Subevents
gdjs.transitionCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), false);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("text_debug_tempo"), gdjs.transitionCode.GDtext_95debug_95tempoObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_timer"), gdjs.transitionCode.GDtext_95timerObjects2);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95debug_95tempoObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95debug_95tempoObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.transitionCode.GDtext_95timerObjects2.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95timerObjects2[i].setOpacity(0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("text_round"), gdjs.transitionCode.GDtext_95roundObjects1);
{for(var i = 0, len = gdjs.transitionCode.GDtext_95roundObjects1.length ;i < len;++i) {
    gdjs.transitionCode.GDtext_95roundObjects1[i].setString("Round " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}

}


};gdjs.transitionCode.eventsList6 = function(runtimeScene) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)), 3));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)))), false);
}}

}


};gdjs.transitionCode.eventsList7 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "transition");
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) <= 0;
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game_over", false);
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
gdjs.transitionCode.condition1IsTrue_0.val = false;
gdjs.transitionCode.condition2IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) > 0;
}if ( gdjs.transitionCode.condition0IsTrue_0.val ) {
{
gdjs.transitionCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "transition") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0));
}if ( gdjs.transitionCode.condition1IsTrue_0.val ) {
{
{gdjs.transitionCode.conditionTrue_1 = gdjs.transitionCode.condition2IsTrue_0;
gdjs.transitionCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12758780);
}
}}
}
if (gdjs.transitionCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.transitionCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.transitionCode.eventsList8 = function(runtimeScene) {

{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}}

}


{


gdjs.transitionCode.condition0IsTrue_0.val = false;
{
gdjs.transitionCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "time_played") >= 1;
}if (gdjs.transitionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("time_played").add(1);
}}

}


};gdjs.transitionCode.eventsList9 = function(runtimeScene) {

{


gdjs.transitionCode.eventsList0(runtimeScene);
}


{


gdjs.transitionCode.eventsList2(runtimeScene);
}


{


gdjs.transitionCode.eventsList5(runtimeScene);
}


{


gdjs.transitionCode.eventsList7(runtimeScene);
}


{


gdjs.transitionCode.eventsList8(runtimeScene);
}


};

gdjs.transitionCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.transitionCode.GDbkg_95transitionObjects1.length = 0;
gdjs.transitionCode.GDbkg_95transitionObjects2.length = 0;
gdjs.transitionCode.GDbkg_95transitionObjects3.length = 0;
gdjs.transitionCode.GDbkg_95transitionObjects4.length = 0;
gdjs.transitionCode.GDtext_95transitionObjects1.length = 0;
gdjs.transitionCode.GDtext_95transitionObjects2.length = 0;
gdjs.transitionCode.GDtext_95transitionObjects3.length = 0;
gdjs.transitionCode.GDtext_95transitionObjects4.length = 0;
gdjs.transitionCode.GDtext_95debug_95tempoObjects1.length = 0;
gdjs.transitionCode.GDtext_95debug_95tempoObjects2.length = 0;
gdjs.transitionCode.GDtext_95debug_95tempoObjects3.length = 0;
gdjs.transitionCode.GDtext_95debug_95tempoObjects4.length = 0;
gdjs.transitionCode.GDMochiObjects1.length = 0;
gdjs.transitionCode.GDMochiObjects2.length = 0;
gdjs.transitionCode.GDMochiObjects3.length = 0;
gdjs.transitionCode.GDMochiObjects4.length = 0;
gdjs.transitionCode.GDtext_95roundObjects1.length = 0;
gdjs.transitionCode.GDtext_95roundObjects2.length = 0;
gdjs.transitionCode.GDtext_95roundObjects3.length = 0;
gdjs.transitionCode.GDtext_95roundObjects4.length = 0;
gdjs.transitionCode.GDtext_95timerObjects1.length = 0;
gdjs.transitionCode.GDtext_95timerObjects2.length = 0;
gdjs.transitionCode.GDtext_95timerObjects3.length = 0;
gdjs.transitionCode.GDtext_95timerObjects4.length = 0;

gdjs.transitionCode.eventsList9(runtimeScene);
return;

}

gdjs['transitionCode'] = gdjs.transitionCode;
