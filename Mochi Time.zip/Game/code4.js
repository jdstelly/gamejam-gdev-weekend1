gdjs.minigame_95cityCode = {};
gdjs.minigame_95cityCode.forEachIndex3 = 0;

gdjs.minigame_95cityCode.forEachObjects3 = [];

gdjs.minigame_95cityCode.forEachTemporary3 = null;

gdjs.minigame_95cityCode.forEachTotalCount3 = 0;

gdjs.minigame_95cityCode.GDbkg_95skyObjects1= [];
gdjs.minigame_95cityCode.GDbkg_95skyObjects2= [];
gdjs.minigame_95cityCode.GDbkg_95skyObjects3= [];
gdjs.minigame_95cityCode.GDbkg_95skyObjects4= [];
gdjs.minigame_95cityCode.GDbkg_95skyObjects5= [];
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects1= [];
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects2= [];
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects3= [];
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects4= [];
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects5= [];
gdjs.minigame_95cityCode.GDbuildingObjects1= [];
gdjs.minigame_95cityCode.GDbuildingObjects2= [];
gdjs.minigame_95cityCode.GDbuildingObjects3= [];
gdjs.minigame_95cityCode.GDbuildingObjects4= [];
gdjs.minigame_95cityCode.GDbuildingObjects5= [];
gdjs.minigame_95cityCode.GDUI_95timerObjects1= [];
gdjs.minigame_95cityCode.GDUI_95timerObjects2= [];
gdjs.minigame_95cityCode.GDUI_95timerObjects3= [];
gdjs.minigame_95cityCode.GDUI_95timerObjects4= [];
gdjs.minigame_95cityCode.GDUI_95timerObjects5= [];
gdjs.minigame_95cityCode.GDroadObjects1= [];
gdjs.minigame_95cityCode.GDroadObjects2= [];
gdjs.minigame_95cityCode.GDroadObjects3= [];
gdjs.minigame_95cityCode.GDroadObjects4= [];
gdjs.minigame_95cityCode.GDroadObjects5= [];
gdjs.minigame_95cityCode.GDMochiObjects1= [];
gdjs.minigame_95cityCode.GDMochiObjects2= [];
gdjs.minigame_95cityCode.GDMochiObjects3= [];
gdjs.minigame_95cityCode.GDMochiObjects4= [];
gdjs.minigame_95cityCode.GDMochiObjects5= [];
gdjs.minigame_95cityCode.GDcontrol_95rightObjects1= [];
gdjs.minigame_95cityCode.GDcontrol_95rightObjects2= [];
gdjs.minigame_95cityCode.GDcontrol_95rightObjects3= [];
gdjs.minigame_95cityCode.GDcontrol_95rightObjects4= [];
gdjs.minigame_95cityCode.GDcontrol_95rightObjects5= [];
gdjs.minigame_95cityCode.GDcontrol_95leftObjects1= [];
gdjs.minigame_95cityCode.GDcontrol_95leftObjects2= [];
gdjs.minigame_95cityCode.GDcontrol_95leftObjects3= [];
gdjs.minigame_95cityCode.GDcontrol_95leftObjects4= [];
gdjs.minigame_95cityCode.GDcontrol_95leftObjects5= [];
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects1= [];
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2= [];
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects3= [];
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects4= [];
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects5= [];
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects1= [];
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2= [];
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects3= [];
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects4= [];
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects5= [];
gdjs.minigame_95cityCode.GDrubbleObjects1= [];
gdjs.minigame_95cityCode.GDrubbleObjects2= [];
gdjs.minigame_95cityCode.GDrubbleObjects3= [];
gdjs.minigame_95cityCode.GDrubbleObjects4= [];
gdjs.minigame_95cityCode.GDrubbleObjects5= [];
gdjs.minigame_95cityCode.GDUI_95livesObjects1= [];
gdjs.minigame_95cityCode.GDUI_95livesObjects2= [];
gdjs.minigame_95cityCode.GDUI_95livesObjects3= [];
gdjs.minigame_95cityCode.GDUI_95livesObjects4= [];
gdjs.minigame_95cityCode.GDUI_95livesObjects5= [];

gdjs.minigame_95cityCode.conditionTrue_0 = {val:false};
gdjs.minigame_95cityCode.condition0IsTrue_0 = {val:false};
gdjs.minigame_95cityCode.condition1IsTrue_0 = {val:false};
gdjs.minigame_95cityCode.condition2IsTrue_0 = {val:false};
gdjs.minigame_95cityCode.condition3IsTrue_0 = {val:false};
gdjs.minigame_95cityCode.conditionTrue_1 = {val:false};
gdjs.minigame_95cityCode.condition0IsTrue_1 = {val:false};
gdjs.minigame_95cityCode.condition1IsTrue_1 = {val:false};
gdjs.minigame_95cityCode.condition2IsTrue_1 = {val:false};
gdjs.minigame_95cityCode.condition3IsTrue_1 = {val:false};


gdjs.minigame_95cityCode.eventsList0 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.minigame_95cityCode.eventsList1 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects1);
gdjs.copyArray(runtimeScene.getObjects("bkg_buildings"), gdjs.minigame_95cityCode.GDbkg_95buildingsObjects1);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbkg_95buildingsObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbkg_95buildingsObjects1[i].setColor("100;100;100");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "minigame");
}{runtimeScene.getVariables().getFromIndex(0).setNumber(14 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 7));
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects1[i].setScale(0.5);
}
}}

}


};gdjs.minigame_95cityCode.eventsList2 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_left"), gdjs.minigame_95cityCode.GDcontrol_95leftObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_right"), gdjs.minigame_95cityCode.GDcontrol_95rightObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_0"), gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_1"), gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95rightObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95rightObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95leftObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95leftObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2[i].setOpacity(0);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition2IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 5;
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= 0.25;
}if ( gdjs.minigame_95cityCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition2IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13039988);
}
}}
}
if (gdjs.minigame_95cityCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_left"), gdjs.minigame_95cityCode.GDcontrol_95leftObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_right"), gdjs.minigame_95cityCode.GDcontrol_95rightObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_0"), gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_1"), gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95leftObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95leftObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95rightObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95rightObjects2[i].setOpacity(255);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= 2;
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 5;
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_left"), gdjs.minigame_95cityCode.GDcontrol_95leftObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_right"), gdjs.minigame_95cityCode.GDcontrol_95rightObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_0"), gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_1"), gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95leftObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95leftObjects2[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDcontrol_95rightObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDcontrol_95rightObjects2[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(2), false);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UI_lives"), gdjs.minigame_95cityCode.GDUI_95livesObjects1);
gdjs.copyArray(runtimeScene.getObjects("UI_timer"), gdjs.minigame_95cityCode.GDUI_95timerObjects1);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDUI_95timerObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDUI_95timerObjects1[i].setString("TIME REMAINING: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.trunc(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) - gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "minigame"))));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDUI_95livesObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDUI_95livesObjects1[i].setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) * 32);
}
}}

}


};gdjs.minigame_95cityCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects4[k] = gdjs.minigame_95cityCode.GDbuildingObjects4[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects4.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].setAnimation(gdjs.randomInRange(3, 6));
}
}}

}


};gdjs.minigame_95cityCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects4[k] = gdjs.minigame_95cityCode.GDbuildingObjects4[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects4.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].setAnimation(gdjs.randomInRange(0, 4));
}
}}

}


};gdjs.minigame_95cityCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects4[k] = gdjs.minigame_95cityCode.GDbuildingObjects4[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects4.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].setAnimation(gdjs.randomInRange(0, 5));
}
}}

}


};gdjs.minigame_95cityCode.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects4[k] = gdjs.minigame_95cityCode.GDbuildingObjects4[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects4.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].setAnimation(gdjs.randomInRange(1, 5));
}
}}

}


};gdjs.minigame_95cityCode.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects4[k] = gdjs.minigame_95cityCode.GDbuildingObjects4[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects4.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects4 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].setAnimation(gdjs.randomInRange(3, 6));
}
}}

}


};gdjs.minigame_95cityCode.eventsList8 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDbuildingObjects3, gdjs.minigame_95cityCode.GDbuildingObjects4);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].returnVariable(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 0;
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 3;
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDbuildingObjects3, gdjs.minigame_95cityCode.GDbuildingObjects4);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].returnVariable(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(0, 1));
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 3;
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 6;
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDbuildingObjects3, gdjs.minigame_95cityCode.GDbuildingObjects4);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].returnVariable(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(0, 1));
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 6;
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 9;
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDbuildingObjects3, gdjs.minigame_95cityCode.GDbuildingObjects4);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].returnVariable(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 9;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDbuildingObjects3, gdjs.minigame_95cityCode.GDbuildingObjects4);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects4.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects4[i].returnVariable(gdjs.minigame_95cityCode.GDbuildingObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95cityCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("building"), gdjs.minigame_95cityCode.GDbuildingObjects2);

for(gdjs.minigame_95cityCode.forEachIndex3 = 0;gdjs.minigame_95cityCode.forEachIndex3 < gdjs.minigame_95cityCode.GDbuildingObjects2.length;++gdjs.minigame_95cityCode.forEachIndex3) {
gdjs.minigame_95cityCode.GDbuildingObjects3.length = 0;


gdjs.minigame_95cityCode.forEachTemporary3 = gdjs.minigame_95cityCode.GDbuildingObjects2[gdjs.minigame_95cityCode.forEachIndex3];
gdjs.minigame_95cityCode.GDbuildingObjects3.push(gdjs.minigame_95cityCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.minigame_95cityCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("building"), gdjs.minigame_95cityCode.GDbuildingObjects1);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDbuildingObjects1.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDbuildingObjects1[i].getVariableNumber(gdjs.minigame_95cityCode.GDbuildingObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDbuildingObjects1[k] = gdjs.minigame_95cityCode.GDbuildingObjects1[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDbuildingObjects1.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects1 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.minigame_95cityCode.eventsList10 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95cityCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95cityCode.eventsList11 = function(runtimeScene) {

{



}


{


{
/* Reuse gdjs.minigame_95cityCode.GDMochiObjects2 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").setMaxSpeed(250 + ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 500));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").setAcceleration(1500 + ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 1500));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(700 + ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 700), false);
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(600 + ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 600));
}
}}

}


};gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDMochiObjects2Objects = Hashtable.newFrom({"Mochi": gdjs.minigame_95cityCode.GDMochiObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDbuildingObjects2Objects = Hashtable.newFrom({"building": gdjs.minigame_95cityCode.GDbuildingObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects = Hashtable.newFrom({"rubble": gdjs.minigame_95cityCode.GDrubbleObjects2});
gdjs.minigame_95cityCode.mapOfEmptyGDbuildingObjects = Hashtable.newFrom({"building": []});
gdjs.minigame_95cityCode.eventsList12 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfEmptyGDbuildingObjects) > 0;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


};gdjs.minigame_95cityCode.mapOfEmptyGDbuildingObjects = Hashtable.newFrom({"building": []});
gdjs.minigame_95cityCode.eventsList13 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition0IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13056732);
}
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UI_timer"), gdjs.minigame_95cityCode.GDUI_95timerObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "victory_timer");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(2), true);
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDUI_95timerObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDUI_95timerObjects2[i].setString("     VICTORY");
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "victory_timer") > 2;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


};gdjs.minigame_95cityCode.eventsList14 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].setX(gdjs.randomInRange(20, 740));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].setY(400);
}
}
{ //Subevents
gdjs.minigame_95cityCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("building"), gdjs.minigame_95cityCode.GDbuildingObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDMochiObjects2Objects, gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDbuildingObjects2Objects, false, runtimeScene, false);
}if ( gdjs.minigame_95cityCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition2IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13060844);
}
}}
}
if (gdjs.minigame_95cityCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDbuildingObjects2 */
gdjs.minigame_95cityCode.GDrubbleObjects2.length = 0;

{for(var i = 0, len = gdjs.minigame_95cityCode.GDbuildingObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDbuildingObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("buildings_destroyed").add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "buildingDestroyed0.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfGDgdjs_46minigame_9595cityCode_46GDrubbleObjects2Objects, (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointX("Center")), (( gdjs.minigame_95cityCode.GDbuildingObjects2.length === 0 ) ? 0 :gdjs.minigame_95cityCode.GDbuildingObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].setAnimation(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.minigame_95cityCode.GDrubbleObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDrubbleObjects2[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(20), 20), gdjs.randomInRange(-(20), 20), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointX("Center")), (gdjs.minigame_95cityCode.GDrubbleObjects2[i].getPointY("Center")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getVariableNumber(gdjs.minigame_95cityCode.GDMochiObjects2[i].getVariables().getFromIndex(0)) < 2 ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDMochiObjects2 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition1IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13050844);
}
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].returnVariable(gdjs.minigame_95cityCode.GDMochiObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDMochiObjects2 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].returnVariable(gdjs.minigame_95cityCode.GDMochiObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{



}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0));
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition1IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13043268);
}
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95cityCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95cityCode.mapOfEmptyGDbuildingObjects) == 0;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95cityCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95cityCode.eventsList15 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "time_played") >= 1;
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("time_played").add(1);
}}

}


};gdjs.minigame_95cityCode.eventsList16 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.minigame_95cityCode.GDMochiObjects2, gdjs.minigame_95cityCode.GDMochiObjects3);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects3[i].setAnimation(1);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95cityCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95cityCode.GDMochiObjects2, gdjs.minigame_95cityCode.GDMochiObjects3);

{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects3[i].setAnimation(0);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition0IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12940980);
}
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "landed0.wav", false, 100, 1);
}}

}


};gdjs.minigame_95cityCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95cityCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition1IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12942212);
}
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDMochiObjects2 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].setAnimation(2);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump0.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);

gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
gdjs.minigame_95cityCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95cityCode.GDMochiObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95cityCode.GDMochiObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.minigame_95cityCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95cityCode.GDMochiObjects2[k] = gdjs.minigame_95cityCode.GDMochiObjects2[i];
        ++k;
    }
}
gdjs.minigame_95cityCode.GDMochiObjects2.length = k;}if ( gdjs.minigame_95cityCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95cityCode.conditionTrue_1 = gdjs.minigame_95cityCode.condition1IsTrue_0;
gdjs.minigame_95cityCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12943636);
}
}}
if (gdjs.minigame_95cityCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95cityCode.GDMochiObjects2 */
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].setAnimation(3);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects2);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects2[i].flipX(true);
}
}}

}


{


gdjs.minigame_95cityCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95cityCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.minigame_95cityCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95cityCode.GDMochiObjects1);
{for(var i = 0, len = gdjs.minigame_95cityCode.GDMochiObjects1.length ;i < len;++i) {
    gdjs.minigame_95cityCode.GDMochiObjects1[i].flipX(false);
}
}}

}


};gdjs.minigame_95cityCode.eventsList18 = function(runtimeScene) {

{


gdjs.minigame_95cityCode.eventsList0(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList1(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList2(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList10(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList14(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList15(runtimeScene);
}


{


gdjs.minigame_95cityCode.eventsList17(runtimeScene);
}


};

gdjs.minigame_95cityCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.minigame_95cityCode.GDbkg_95skyObjects1.length = 0;
gdjs.minigame_95cityCode.GDbkg_95skyObjects2.length = 0;
gdjs.minigame_95cityCode.GDbkg_95skyObjects3.length = 0;
gdjs.minigame_95cityCode.GDbkg_95skyObjects4.length = 0;
gdjs.minigame_95cityCode.GDbkg_95skyObjects5.length = 0;
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects1.length = 0;
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects2.length = 0;
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects3.length = 0;
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects4.length = 0;
gdjs.minigame_95cityCode.GDbkg_95buildingsObjects5.length = 0;
gdjs.minigame_95cityCode.GDbuildingObjects1.length = 0;
gdjs.minigame_95cityCode.GDbuildingObjects2.length = 0;
gdjs.minigame_95cityCode.GDbuildingObjects3.length = 0;
gdjs.minigame_95cityCode.GDbuildingObjects4.length = 0;
gdjs.minigame_95cityCode.GDbuildingObjects5.length = 0;
gdjs.minigame_95cityCode.GDUI_95timerObjects1.length = 0;
gdjs.minigame_95cityCode.GDUI_95timerObjects2.length = 0;
gdjs.minigame_95cityCode.GDUI_95timerObjects3.length = 0;
gdjs.minigame_95cityCode.GDUI_95timerObjects4.length = 0;
gdjs.minigame_95cityCode.GDUI_95timerObjects5.length = 0;
gdjs.minigame_95cityCode.GDroadObjects1.length = 0;
gdjs.minigame_95cityCode.GDroadObjects2.length = 0;
gdjs.minigame_95cityCode.GDroadObjects3.length = 0;
gdjs.minigame_95cityCode.GDroadObjects4.length = 0;
gdjs.minigame_95cityCode.GDroadObjects5.length = 0;
gdjs.minigame_95cityCode.GDMochiObjects1.length = 0;
gdjs.minigame_95cityCode.GDMochiObjects2.length = 0;
gdjs.minigame_95cityCode.GDMochiObjects3.length = 0;
gdjs.minigame_95cityCode.GDMochiObjects4.length = 0;
gdjs.minigame_95cityCode.GDMochiObjects5.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95rightObjects1.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95rightObjects2.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95rightObjects3.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95rightObjects4.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95rightObjects5.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95leftObjects1.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95leftObjects2.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95leftObjects3.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95leftObjects4.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95leftObjects5.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects1.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects2.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects3.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects4.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_950Objects5.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects1.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects2.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects3.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects4.length = 0;
gdjs.minigame_95cityCode.GDcontrol_95space_951Objects5.length = 0;
gdjs.minigame_95cityCode.GDrubbleObjects1.length = 0;
gdjs.minigame_95cityCode.GDrubbleObjects2.length = 0;
gdjs.minigame_95cityCode.GDrubbleObjects3.length = 0;
gdjs.minigame_95cityCode.GDrubbleObjects4.length = 0;
gdjs.minigame_95cityCode.GDrubbleObjects5.length = 0;
gdjs.minigame_95cityCode.GDUI_95livesObjects1.length = 0;
gdjs.minigame_95cityCode.GDUI_95livesObjects2.length = 0;
gdjs.minigame_95cityCode.GDUI_95livesObjects3.length = 0;
gdjs.minigame_95cityCode.GDUI_95livesObjects4.length = 0;
gdjs.minigame_95cityCode.GDUI_95livesObjects5.length = 0;

gdjs.minigame_95cityCode.eventsList18(runtimeScene);
return;

}

gdjs['minigame_95cityCode'] = gdjs.minigame_95cityCode;
