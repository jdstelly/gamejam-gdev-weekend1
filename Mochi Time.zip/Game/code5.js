gdjs.minigame_95paperCode = {};
gdjs.minigame_95paperCode.GDdryerObjects2_1final = [];

gdjs.minigame_95paperCode.GDpawObjects2_1final = [];

gdjs.minigame_95paperCode.GDtowel_95singleObjects2_1final = [];

gdjs.minigame_95paperCode.GDbkg_95dispenserObjects1= [];
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects2= [];
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3= [];
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects4= [];
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects5= [];
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects1= [];
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects2= [];
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects3= [];
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects4= [];
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects5= [];
gdjs.minigame_95paperCode.GDpaper_95towelsObjects1= [];
gdjs.minigame_95paperCode.GDpaper_95towelsObjects2= [];
gdjs.minigame_95paperCode.GDpaper_95towelsObjects3= [];
gdjs.minigame_95paperCode.GDpaper_95towelsObjects4= [];
gdjs.minigame_95paperCode.GDpaper_95towelsObjects5= [];
gdjs.minigame_95paperCode.GDleverObjects1= [];
gdjs.minigame_95paperCode.GDleverObjects2= [];
gdjs.minigame_95paperCode.GDleverObjects3= [];
gdjs.minigame_95paperCode.GDleverObjects4= [];
gdjs.minigame_95paperCode.GDleverObjects5= [];
gdjs.minigame_95paperCode.GDsignObjects1= [];
gdjs.minigame_95paperCode.GDsignObjects2= [];
gdjs.minigame_95paperCode.GDsignObjects3= [];
gdjs.minigame_95paperCode.GDsignObjects4= [];
gdjs.minigame_95paperCode.GDsignObjects5= [];
gdjs.minigame_95paperCode.GDtext_95signObjects1= [];
gdjs.minigame_95paperCode.GDtext_95signObjects2= [];
gdjs.minigame_95paperCode.GDtext_95signObjects3= [];
gdjs.minigame_95paperCode.GDtext_95signObjects4= [];
gdjs.minigame_95paperCode.GDtext_95signObjects5= [];
gdjs.minigame_95paperCode.GDtext_95sign_951Objects1= [];
gdjs.minigame_95paperCode.GDtext_95sign_951Objects2= [];
gdjs.minigame_95paperCode.GDtext_95sign_951Objects3= [];
gdjs.minigame_95paperCode.GDtext_95sign_951Objects4= [];
gdjs.minigame_95paperCode.GDtext_95sign_951Objects5= [];
gdjs.minigame_95paperCode.GDbkg_95doorObjects1= [];
gdjs.minigame_95paperCode.GDbkg_95doorObjects2= [];
gdjs.minigame_95paperCode.GDbkg_95doorObjects3= [];
gdjs.minigame_95paperCode.GDbkg_95doorObjects4= [];
gdjs.minigame_95paperCode.GDbkg_95doorObjects5= [];
gdjs.minigame_95paperCode.GDtowel_95singleObjects1= [];
gdjs.minigame_95paperCode.GDtowel_95singleObjects2= [];
gdjs.minigame_95paperCode.GDtowel_95singleObjects3= [];
gdjs.minigame_95paperCode.GDtowel_95singleObjects4= [];
gdjs.minigame_95paperCode.GDtowel_95singleObjects5= [];
gdjs.minigame_95paperCode.GDtowel_95staticObjects1= [];
gdjs.minigame_95paperCode.GDtowel_95staticObjects2= [];
gdjs.minigame_95paperCode.GDtowel_95staticObjects3= [];
gdjs.minigame_95paperCode.GDtowel_95staticObjects4= [];
gdjs.minigame_95paperCode.GDtowel_95staticObjects5= [];
gdjs.minigame_95paperCode.GDpawObjects1= [];
gdjs.minigame_95paperCode.GDpawObjects2= [];
gdjs.minigame_95paperCode.GDpawObjects3= [];
gdjs.minigame_95paperCode.GDpawObjects4= [];
gdjs.minigame_95paperCode.GDpawObjects5= [];
gdjs.minigame_95paperCode.GDphys_95floorObjects1= [];
gdjs.minigame_95paperCode.GDphys_95floorObjects2= [];
gdjs.minigame_95paperCode.GDphys_95floorObjects3= [];
gdjs.minigame_95paperCode.GDphys_95floorObjects4= [];
gdjs.minigame_95paperCode.GDphys_95floorObjects5= [];
gdjs.minigame_95paperCode.GDphys_95wallObjects1= [];
gdjs.minigame_95paperCode.GDphys_95wallObjects2= [];
gdjs.minigame_95paperCode.GDphys_95wallObjects3= [];
gdjs.minigame_95paperCode.GDphys_95wallObjects4= [];
gdjs.minigame_95paperCode.GDphys_95wallObjects5= [];
gdjs.minigame_95paperCode.GDdryerObjects1= [];
gdjs.minigame_95paperCode.GDdryerObjects2= [];
gdjs.minigame_95paperCode.GDdryerObjects3= [];
gdjs.minigame_95paperCode.GDdryerObjects4= [];
gdjs.minigame_95paperCode.GDdryerObjects5= [];
gdjs.minigame_95paperCode.GDtext_95dryerObjects1= [];
gdjs.minigame_95paperCode.GDtext_95dryerObjects2= [];
gdjs.minigame_95paperCode.GDtext_95dryerObjects3= [];
gdjs.minigame_95paperCode.GDtext_95dryerObjects4= [];
gdjs.minigame_95paperCode.GDtext_95dryerObjects5= [];
gdjs.minigame_95paperCode.GDUI_95timerObjects1= [];
gdjs.minigame_95paperCode.GDUI_95timerObjects2= [];
gdjs.minigame_95paperCode.GDUI_95timerObjects3= [];
gdjs.minigame_95paperCode.GDUI_95timerObjects4= [];
gdjs.minigame_95paperCode.GDUI_95timerObjects5= [];
gdjs.minigame_95paperCode.GDbroken_95leverObjects1= [];
gdjs.minigame_95paperCode.GDbroken_95leverObjects2= [];
gdjs.minigame_95paperCode.GDbroken_95leverObjects3= [];
gdjs.minigame_95paperCode.GDbroken_95leverObjects4= [];
gdjs.minigame_95paperCode.GDbroken_95leverObjects5= [];
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects1= [];
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2= [];
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects3= [];
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects4= [];
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects5= [];
gdjs.minigame_95paperCode.GDsign_95fallenObjects1= [];
gdjs.minigame_95paperCode.GDsign_95fallenObjects2= [];
gdjs.minigame_95paperCode.GDsign_95fallenObjects3= [];
gdjs.minigame_95paperCode.GDsign_95fallenObjects4= [];
gdjs.minigame_95paperCode.GDsign_95fallenObjects5= [];
gdjs.minigame_95paperCode.GDUI_95livesObjects1= [];
gdjs.minigame_95paperCode.GDUI_95livesObjects2= [];
gdjs.minigame_95paperCode.GDUI_95livesObjects3= [];
gdjs.minigame_95paperCode.GDUI_95livesObjects4= [];
gdjs.minigame_95paperCode.GDUI_95livesObjects5= [];

gdjs.minigame_95paperCode.conditionTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition0IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition1IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition2IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition3IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition4IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.condition5IsTrue_0 = {val:false};
gdjs.minigame_95paperCode.conditionTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition0IsTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition1IsTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition2IsTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition3IsTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition4IsTrue_1 = {val:false};
gdjs.minigame_95paperCode.condition5IsTrue_1 = {val:false};


gdjs.minigame_95paperCode.eventsList0 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.minigame_95paperCode.eventsList1 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 55;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(55);
}}

}


{



}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 0;
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 3;
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 3;
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 6;
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(15);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 6;
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 9;
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(25);
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 9;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(33);
}}

}


};gdjs.minigame_95paperCode.eventsList2 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_mouse"), gdjs.minigame_95paperCode.GDcontrol_95mouseObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "minigame");
}{runtimeScene.getVariables().getFromIndex(4).setNumber(15 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 5));
}{runtimeScene.getVariables().getFromIndex(2).setNumber(10 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) * 3));
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 4));
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDcontrol_95mouseObjects1.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDcontrol_95mouseObjects1[i].setOpacity(0);
}
}
{ //Subevents
gdjs.minigame_95paperCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95paperCode.eventsList3 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 5;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_mouse"), gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2[i].setOpacity(255);
}
}}

}


};gdjs.minigame_95paperCode.eventsList4 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= 2;
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 5;
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_mouse"), gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(5), false);
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UI_lives"), gdjs.minigame_95paperCode.GDUI_95livesObjects1);
gdjs.copyArray(runtimeScene.getObjects("UI_timer"), gdjs.minigame_95paperCode.GDUI_95timerObjects1);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDUI_95timerObjects1.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDUI_95timerObjects1[i].setString("TIME REMAINING: " + gdjs.evtTools.common.toString(gdjs.evtTools.common.trunc(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) - gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "minigame"))));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDUI_95livesObjects1.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDUI_95livesObjects1[i].setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) * 32);
}
}}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects = Hashtable.newFrom({"paw": gdjs.minigame_95paperCode.GDpawObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDleverObjects3Objects = Hashtable.newFrom({"lever": gdjs.minigame_95paperCode.GDleverObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects = Hashtable.newFrom({"paw": gdjs.minigame_95paperCode.GDpawObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects = Hashtable.newFrom({"towel_single": gdjs.minigame_95paperCode.GDtowel_95singleObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDbroken_9595leverObjects3Objects = Hashtable.newFrom({"broken_lever": gdjs.minigame_95paperCode.GDbroken_95leverObjects3});
gdjs.minigame_95paperCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.minigame_95paperCode.GDleverObjects3, gdjs.minigame_95paperCode.GDleverObjects4);


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects4[i].getVariableNumber(gdjs.minigame_95paperCode.GDleverObjects4[i].getVariables().getFromIndex(3)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects4[k] = gdjs.minigame_95paperCode.GDleverObjects4[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects4.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95paperCode.GDleverObjects4 */
{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects4.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects4[i].setVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects4[i].getVariables().getFromIndex(0), true);
}
}}

}


{

/* Reuse gdjs.minigame_95paperCode.GDleverObjects3 */

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects3[i].getVariableNumber(gdjs.minigame_95paperCode.GDleverObjects3[i].getVariables().getFromIndex(3)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects3[k] = gdjs.minigame_95paperCode.GDleverObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects3.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bkg_dispenser"), gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3);
/* Reuse gdjs.minigame_95paperCode.GDleverObjects3 */
/* Reuse gdjs.minigame_95paperCode.GDtowel_95singleObjects3 */
gdjs.minigame_95paperCode.GDbroken_95leverObjects3.length = 0;

{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].setVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects3[i].getVariables().getFromIndex(1), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "lever_break.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].setAnimation(2);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDbroken_9595leverObjects3Objects, (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointX("spawn_towel")), (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointY("spawn_towel")), "");
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDbroken_95leverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDbroken_95leverObjects3[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(10), 10), gdjs.randomInRange(-(25), 10), (( gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDtowel_95singleObjects3[0].getPointX("Center")), (( gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDtowel_95singleObjects3[0].getPointY("Center")));
}
}}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects = Hashtable.newFrom({"towel_single": gdjs.minigame_95paperCode.GDtowel_95singleObjects3});
gdjs.minigame_95paperCode.eventsList6 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 0;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bkg_dispenser"), gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3);
gdjs.copyArray(runtimeScene.getObjects("towel_static"), gdjs.minigame_95paperCode.GDtowel_95staticObjects3);
gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length = 0;

{runtimeScene.getVariables().getFromIndex(2).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects, (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointX("spawn_towel")), (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointY("spawn_towel")), "");
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(10), 10), gdjs.randomInRange(-(25), 10), (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointX("Center")), (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointY("Center")));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95staticObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95staticObjects3[i].setLayer("Hidden");
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("paper_towels_used").add(1);
}}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects2Objects = Hashtable.newFrom({"paw": gdjs.minigame_95paperCode.GDpawObjects2});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDleverObjects2Objects = Hashtable.newFrom({"lever": gdjs.minigame_95paperCode.GDleverObjects2});
gdjs.minigame_95paperCode.eventsList7 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 0;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("towel_static"), gdjs.minigame_95paperCode.GDtowel_95staticObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95staticObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95staticObjects2[i].setLayer("");
}
}}

}


};gdjs.minigame_95paperCode.eventsList8 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition0IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13320108);
}
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95paperCode.GDleverObjects2, gdjs.minigame_95paperCode.GDleverObjects3);

{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].resetTimer("reset_time");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "dispense.wav", false, 100, 1);
}
{ //Subevents
gdjs.minigame_95paperCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.minigame_95paperCode.GDleverObjects2 */
gdjs.copyArray(runtimeScene.getObjects("paw"), gdjs.minigame_95paperCode.GDpawObjects2);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects2[i].getTimerElapsedTimeInSecondsOrNaN("reset_time") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects2[k] = gdjs.minigame_95paperCode.GDleverObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects2.length = k;}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects2Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDleverObjects2Objects, true, runtimeScene, false);
}if ( gdjs.minigame_95paperCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition2IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13325740);
}
}}
}
if (gdjs.minigame_95paperCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95paperCode.GDleverObjects2 */
{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects2[i].setVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects2[i].setAnimation(0);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "lever_reset.wav", false, 100, 1);
}
{ //Subevents
gdjs.minigame_95paperCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95paperCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.minigame_95paperCode.GDleverObjects2, gdjs.minigame_95paperCode.GDleverObjects3);

gdjs.copyArray(runtimeScene.getObjects("paw"), gdjs.minigame_95paperCode.GDpawObjects3);
gdjs.copyArray(runtimeScene.getObjects("towel_single"), gdjs.minigame_95paperCode.GDtowel_95singleObjects3);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition2IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition3IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition4IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDleverObjects3Objects, false, runtimeScene, false);
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects3[i].getAnimation() == 0 ) {
        gdjs.minigame_95paperCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects3[k] = gdjs.minigame_95paperCode.GDleverObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects3.length = k;}if ( gdjs.minigame_95paperCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects3[i].getVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.minigame_95paperCode.condition2IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects3[k] = gdjs.minigame_95paperCode.GDleverObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects3.length = k;}if ( gdjs.minigame_95paperCode.condition2IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects, true, runtimeScene, false);
}if ( gdjs.minigame_95paperCode.condition3IsTrue_0.val ) {
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition4IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13315220);
}
}}
}
}
}
if (gdjs.minigame_95paperCode.condition4IsTrue_0.val) {
/* Reuse gdjs.minigame_95paperCode.GDleverObjects3 */
{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDleverObjects3[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange(1, 100));
}
}
{ //Subevents
gdjs.minigame_95paperCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.minigame_95paperCode.GDleverObjects2 */

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects2[i].getVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects2[k] = gdjs.minigame_95paperCode.GDleverObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects2.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects = Hashtable.newFrom({"paw": gdjs.minigame_95paperCode.GDpawObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595staticObjects3Objects = Hashtable.newFrom({"towel_static": gdjs.minigame_95paperCode.GDtowel_95staticObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects = Hashtable.newFrom({"towel_single": gdjs.minigame_95paperCode.GDtowel_95singleObjects3});
gdjs.minigame_95paperCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("paw"), gdjs.minigame_95paperCode.GDpawObjects3);
gdjs.copyArray(runtimeScene.getObjects("towel_static"), gdjs.minigame_95paperCode.GDtowel_95staticObjects3);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition2IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition3IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595staticObjects3Objects, false, runtimeScene, true);
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDtowel_95staticObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDtowel_95staticObjects3[i].isOnLayer("") ) {
        gdjs.minigame_95paperCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDtowel_95staticObjects3[k] = gdjs.minigame_95paperCode.GDtowel_95staticObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDtowel_95staticObjects3.length = k;}if ( gdjs.minigame_95paperCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDpawObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDpawObjects3[i].getVariableNumber(gdjs.minigame_95paperCode.GDpawObjects3[i].getVariables().getFromIndex(0)) != gdjs.evtTools.input.getMouseY(runtimeScene, "", 0) ) {
        gdjs.minigame_95paperCode.condition2IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDpawObjects3[k] = gdjs.minigame_95paperCode.GDpawObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDpawObjects3.length = k;}if ( gdjs.minigame_95paperCode.condition2IsTrue_0.val ) {
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition3IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13328884);
}
}}
}
}
if (gdjs.minigame_95paperCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bkg_dispenser"), gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3);
gdjs.copyArray(gdjs.minigame_95paperCode.GDleverObjects2, gdjs.minigame_95paperCode.GDleverObjects3);

/* Reuse gdjs.minigame_95paperCode.GDpawObjects3 */
/* Reuse gdjs.minigame_95paperCode.GDtowel_95staticObjects3 */
gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length = 0;

{for(var i = 0, len = gdjs.minigame_95paperCode.GDleverObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDleverObjects3[i].resetTimer("reset_time");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ripTowel.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(2).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects, (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointX("spawn_towel")), (( gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3[0].getPointY("spawn_towel")), "");
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getBehavior("Physics2").applyForce(gdjs.randomInRange((-(5) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 15), (5 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 15)), gdjs.randomInRange((-(5) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 25), (5 + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 15)), (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointX("Center")), (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointY("Center")));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95staticObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95staticObjects3[i].setLayer("Hidden");
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("paper_towels_used").add(1);
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDpawObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDpawObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDpawObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(-(5), 5));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(-(5), 5));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomInRange(-(5), 5));
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].returnVariable(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange(-(5), 5));
}
}}

}


{

/* Reuse gdjs.minigame_95paperCode.GDleverObjects2 */

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects2[i].getTimerElapsedTimeInSecondsOrNaN("reset_time") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects2[k] = gdjs.minigame_95paperCode.GDleverObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects2.length = k;}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95paperCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 0;
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("towel_static"), gdjs.minigame_95paperCode.GDtowel_95staticObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95staticObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95staticObjects2[i].setLayer("");
}
}}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects = Hashtable.newFrom({"paw": gdjs.minigame_95paperCode.GDpawObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDdryerObjects3Objects = Hashtable.newFrom({"dryer": gdjs.minigame_95paperCode.GDdryerObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects = Hashtable.newFrom({"towel_single": gdjs.minigame_95paperCode.GDtowel_95singleObjects3});
gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDdryerObjects3Objects = Hashtable.newFrom({"dryer": gdjs.minigame_95paperCode.GDdryerObjects3});
gdjs.minigame_95paperCode.eventsList11 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition0IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13338644);
}
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95paperCode.GDdryerObjects2, gdjs.minigame_95paperCode.GDdryerObjects3);

{for(var i = 0, len = gdjs.minigame_95paperCode.GDdryerObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDdryerObjects3[i].resetTimer("run_time");
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDdryerObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDdryerObjects3[i].setAnimation(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "airdry.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.minigame_95paperCode.GDdryerObjects2, gdjs.minigame_95paperCode.GDdryerObjects3);


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDdryerObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDdryerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("run_time") <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDdryerObjects3[k] = gdjs.minigame_95paperCode.GDdryerObjects3[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDdryerObjects3.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("towel_single"), gdjs.minigame_95paperCode.GDtowel_95singleObjects3);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getBehavior("Physics2").applyForce(gdjs.randomInRange(-(5), 5), gdjs.randomInRange(-(5), 5), (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointX("Center")) - 24, (gdjs.minigame_95paperCode.GDtowel_95singleObjects3[i].getPointY("Center")));
}
}}

}


{

/* Reuse gdjs.minigame_95paperCode.GDdryerObjects2 */

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDdryerObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDdryerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("run_time") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) + (10 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDdryerObjects2[k] = gdjs.minigame_95paperCode.GDdryerObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDdryerObjects2.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95paperCode.GDdryerObjects2 */
{for(var i = 0, len = gdjs.minigame_95paperCode.GDdryerObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDdryerObjects2[i].setVariableBoolean(gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDdryerObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDdryerObjects2[i].setAnimation(0);
}
}}

}


};gdjs.minigame_95paperCode.eventsList12 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > 0;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


};gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDsign_9595fallenObjects2Objects = Hashtable.newFrom({"sign_fallen": gdjs.minigame_95paperCode.GDsign_95fallenObjects2});
gdjs.minigame_95paperCode.eventsList13 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition0IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13345324);
}
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UI_timer"), gdjs.minigame_95paperCode.GDUI_95timerObjects2);
gdjs.copyArray(runtimeScene.getObjects("sign"), gdjs.minigame_95paperCode.GDsignObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_sign"), gdjs.minigame_95paperCode.GDtext_95signObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_sign_1"), gdjs.minigame_95paperCode.GDtext_95sign_951Objects2);
gdjs.minigame_95paperCode.GDsign_95fallenObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "victory_timer");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(5), true);
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDUI_95timerObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDUI_95timerObjects2[i].setString("     VICTORY");
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDsignObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDsignObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtext_95signObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtext_95signObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDtext_95sign_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDtext_95sign_951Objects2[i].setOpacity(0);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDsign_9595fallenObjects2Objects, (( gdjs.minigame_95paperCode.GDsignObjects2.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDsignObjects2[0].getPointX("Center")), (( gdjs.minigame_95paperCode.GDsignObjects2.length === 0 ) ? 0 :gdjs.minigame_95paperCode.GDsignObjects2[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95paperCode.GDsign_95fallenObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDsign_95fallenObjects2[i].getBehavior("Physics2").applyForce(125, -(50), (gdjs.minigame_95paperCode.GDsign_95fallenObjects2[i].getPointX("fall_force")), (gdjs.minigame_95paperCode.GDsign_95fallenObjects2[i].getPointY("fall_force")));
}
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "victory_timer") > 2;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


};gdjs.minigame_95paperCode.eventsList14 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("paw"), gdjs.minigame_95paperCode.GDpawObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDpawObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDpawObjects2[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("paper_towels"), gdjs.minigame_95paperCode.GDpaper_95towelsObjects2);
{for(var i = 0, len = gdjs.minigame_95paperCode.GDpaper_95towelsObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDpaper_95towelsObjects2[i].setHeight(-(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2))) * 2);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("lever"), gdjs.minigame_95paperCode.GDleverObjects2);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects2[i].getVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects2[i].getVariables().getFromIndex(1), false) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects2[k] = gdjs.minigame_95paperCode.GDleverObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects2.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("lever"), gdjs.minigame_95paperCode.GDleverObjects2);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDleverObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDleverObjects2[i].getVariableBoolean(gdjs.minigame_95paperCode.GDleverObjects2[i].getVariables().getFromIndex(1), true) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDleverObjects2[k] = gdjs.minigame_95paperCode.GDleverObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDleverObjects2.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.minigame_95paperCode.GDdryerObjects2.length = 0;

gdjs.minigame_95paperCode.GDpawObjects2.length = 0;

gdjs.minigame_95paperCode.GDtowel_95singleObjects2.length = 0;


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition0IsTrue_0;
gdjs.minigame_95paperCode.GDdryerObjects2_1final.length = 0;gdjs.minigame_95paperCode.GDpawObjects2_1final.length = 0;gdjs.minigame_95paperCode.GDtowel_95singleObjects2_1final.length = 0;gdjs.minigame_95paperCode.condition0IsTrue_1.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("dryer"), gdjs.minigame_95paperCode.GDdryerObjects3);
gdjs.copyArray(runtimeScene.getObjects("paw"), gdjs.minigame_95paperCode.GDpawObjects3);
gdjs.minigame_95paperCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDpawObjects3Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDdryerObjects3Objects, false, runtimeScene, false);
if( gdjs.minigame_95paperCode.condition0IsTrue_1.val ) {
    gdjs.minigame_95paperCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.minigame_95paperCode.GDdryerObjects3.length;j<jLen;++j) {
        if ( gdjs.minigame_95paperCode.GDdryerObjects2_1final.indexOf(gdjs.minigame_95paperCode.GDdryerObjects3[j]) === -1 )
            gdjs.minigame_95paperCode.GDdryerObjects2_1final.push(gdjs.minigame_95paperCode.GDdryerObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.minigame_95paperCode.GDpawObjects3.length;j<jLen;++j) {
        if ( gdjs.minigame_95paperCode.GDpawObjects2_1final.indexOf(gdjs.minigame_95paperCode.GDpawObjects3[j]) === -1 )
            gdjs.minigame_95paperCode.GDpawObjects2_1final.push(gdjs.minigame_95paperCode.GDpawObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("dryer"), gdjs.minigame_95paperCode.GDdryerObjects3);
gdjs.copyArray(runtimeScene.getObjects("towel_single"), gdjs.minigame_95paperCode.GDtowel_95singleObjects3);
gdjs.minigame_95paperCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDtowel_9595singleObjects3Objects, gdjs.minigame_95paperCode.mapOfGDgdjs_46minigame_9595paperCode_46GDdryerObjects3Objects, false, runtimeScene, false);
if( gdjs.minigame_95paperCode.condition1IsTrue_1.val ) {
    gdjs.minigame_95paperCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.minigame_95paperCode.GDdryerObjects3.length;j<jLen;++j) {
        if ( gdjs.minigame_95paperCode.GDdryerObjects2_1final.indexOf(gdjs.minigame_95paperCode.GDdryerObjects3[j]) === -1 )
            gdjs.minigame_95paperCode.GDdryerObjects2_1final.push(gdjs.minigame_95paperCode.GDdryerObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length;j<jLen;++j) {
        if ( gdjs.minigame_95paperCode.GDtowel_95singleObjects2_1final.indexOf(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[j]) === -1 )
            gdjs.minigame_95paperCode.GDtowel_95singleObjects2_1final.push(gdjs.minigame_95paperCode.GDtowel_95singleObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.minigame_95paperCode.GDdryerObjects2_1final, gdjs.minigame_95paperCode.GDdryerObjects2);
gdjs.copyArray(gdjs.minigame_95paperCode.GDpawObjects2_1final, gdjs.minigame_95paperCode.GDpawObjects2);
gdjs.copyArray(gdjs.minigame_95paperCode.GDtowel_95singleObjects2_1final, gdjs.minigame_95paperCode.GDtowel_95singleObjects2);
}
}
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDdryerObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariableBoolean(gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.minigame_95paperCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDdryerObjects2[k] = gdjs.minigame_95paperCode.GDdryerObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDdryerObjects2.length = k;}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95paperCode.GDdryerObjects2 */
{for(var i = 0, len = gdjs.minigame_95paperCode.GDdryerObjects2.length ;i < len;++i) {
    gdjs.minigame_95paperCode.GDdryerObjects2[i].setVariableBoolean(gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("dryer"), gdjs.minigame_95paperCode.GDdryerObjects2);

gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95paperCode.GDdryerObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariableBoolean(gdjs.minigame_95paperCode.GDdryerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.minigame_95paperCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95paperCode.GDdryerObjects2[k] = gdjs.minigame_95paperCode.GDdryerObjects2[i];
        ++k;
    }
}
gdjs.minigame_95paperCode.GDdryerObjects2.length = k;}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
gdjs.minigame_95paperCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4));
}if ( gdjs.minigame_95paperCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95paperCode.conditionTrue_1 = gdjs.minigame_95paperCode.condition1IsTrue_0;
gdjs.minigame_95paperCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13343292);
}
}}
if (gdjs.minigame_95paperCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) <= 0;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95paperCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95paperCode.eventsList15 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}}

}


{


gdjs.minigame_95paperCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95paperCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "time_played") >= 1;
}if (gdjs.minigame_95paperCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("time_played").add(1);
}}

}


};gdjs.minigame_95paperCode.eventsList16 = function(runtimeScene) {

{


gdjs.minigame_95paperCode.eventsList0(runtimeScene);
}


{


gdjs.minigame_95paperCode.eventsList2(runtimeScene);
}


{


gdjs.minigame_95paperCode.eventsList4(runtimeScene);
}


{


gdjs.minigame_95paperCode.eventsList14(runtimeScene);
}


{


gdjs.minigame_95paperCode.eventsList15(runtimeScene);
}


};

gdjs.minigame_95paperCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.minigame_95paperCode.GDbkg_95dispenserObjects1.length = 0;
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects2.length = 0;
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects3.length = 0;
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects4.length = 0;
gdjs.minigame_95paperCode.GDbkg_95dispenserObjects5.length = 0;
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects1.length = 0;
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects2.length = 0;
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects3.length = 0;
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects4.length = 0;
gdjs.minigame_95paperCode.GDbkg_95bathroomObjects5.length = 0;
gdjs.minigame_95paperCode.GDpaper_95towelsObjects1.length = 0;
gdjs.minigame_95paperCode.GDpaper_95towelsObjects2.length = 0;
gdjs.minigame_95paperCode.GDpaper_95towelsObjects3.length = 0;
gdjs.minigame_95paperCode.GDpaper_95towelsObjects4.length = 0;
gdjs.minigame_95paperCode.GDpaper_95towelsObjects5.length = 0;
gdjs.minigame_95paperCode.GDleverObjects1.length = 0;
gdjs.minigame_95paperCode.GDleverObjects2.length = 0;
gdjs.minigame_95paperCode.GDleverObjects3.length = 0;
gdjs.minigame_95paperCode.GDleverObjects4.length = 0;
gdjs.minigame_95paperCode.GDleverObjects5.length = 0;
gdjs.minigame_95paperCode.GDsignObjects1.length = 0;
gdjs.minigame_95paperCode.GDsignObjects2.length = 0;
gdjs.minigame_95paperCode.GDsignObjects3.length = 0;
gdjs.minigame_95paperCode.GDsignObjects4.length = 0;
gdjs.minigame_95paperCode.GDsignObjects5.length = 0;
gdjs.minigame_95paperCode.GDtext_95signObjects1.length = 0;
gdjs.minigame_95paperCode.GDtext_95signObjects2.length = 0;
gdjs.minigame_95paperCode.GDtext_95signObjects3.length = 0;
gdjs.minigame_95paperCode.GDtext_95signObjects4.length = 0;
gdjs.minigame_95paperCode.GDtext_95signObjects5.length = 0;
gdjs.minigame_95paperCode.GDtext_95sign_951Objects1.length = 0;
gdjs.minigame_95paperCode.GDtext_95sign_951Objects2.length = 0;
gdjs.minigame_95paperCode.GDtext_95sign_951Objects3.length = 0;
gdjs.minigame_95paperCode.GDtext_95sign_951Objects4.length = 0;
gdjs.minigame_95paperCode.GDtext_95sign_951Objects5.length = 0;
gdjs.minigame_95paperCode.GDbkg_95doorObjects1.length = 0;
gdjs.minigame_95paperCode.GDbkg_95doorObjects2.length = 0;
gdjs.minigame_95paperCode.GDbkg_95doorObjects3.length = 0;
gdjs.minigame_95paperCode.GDbkg_95doorObjects4.length = 0;
gdjs.minigame_95paperCode.GDbkg_95doorObjects5.length = 0;
gdjs.minigame_95paperCode.GDtowel_95singleObjects1.length = 0;
gdjs.minigame_95paperCode.GDtowel_95singleObjects2.length = 0;
gdjs.minigame_95paperCode.GDtowel_95singleObjects3.length = 0;
gdjs.minigame_95paperCode.GDtowel_95singleObjects4.length = 0;
gdjs.minigame_95paperCode.GDtowel_95singleObjects5.length = 0;
gdjs.minigame_95paperCode.GDtowel_95staticObjects1.length = 0;
gdjs.minigame_95paperCode.GDtowel_95staticObjects2.length = 0;
gdjs.minigame_95paperCode.GDtowel_95staticObjects3.length = 0;
gdjs.minigame_95paperCode.GDtowel_95staticObjects4.length = 0;
gdjs.minigame_95paperCode.GDtowel_95staticObjects5.length = 0;
gdjs.minigame_95paperCode.GDpawObjects1.length = 0;
gdjs.minigame_95paperCode.GDpawObjects2.length = 0;
gdjs.minigame_95paperCode.GDpawObjects3.length = 0;
gdjs.minigame_95paperCode.GDpawObjects4.length = 0;
gdjs.minigame_95paperCode.GDpawObjects5.length = 0;
gdjs.minigame_95paperCode.GDphys_95floorObjects1.length = 0;
gdjs.minigame_95paperCode.GDphys_95floorObjects2.length = 0;
gdjs.minigame_95paperCode.GDphys_95floorObjects3.length = 0;
gdjs.minigame_95paperCode.GDphys_95floorObjects4.length = 0;
gdjs.minigame_95paperCode.GDphys_95floorObjects5.length = 0;
gdjs.minigame_95paperCode.GDphys_95wallObjects1.length = 0;
gdjs.minigame_95paperCode.GDphys_95wallObjects2.length = 0;
gdjs.minigame_95paperCode.GDphys_95wallObjects3.length = 0;
gdjs.minigame_95paperCode.GDphys_95wallObjects4.length = 0;
gdjs.minigame_95paperCode.GDphys_95wallObjects5.length = 0;
gdjs.minigame_95paperCode.GDdryerObjects1.length = 0;
gdjs.minigame_95paperCode.GDdryerObjects2.length = 0;
gdjs.minigame_95paperCode.GDdryerObjects3.length = 0;
gdjs.minigame_95paperCode.GDdryerObjects4.length = 0;
gdjs.minigame_95paperCode.GDdryerObjects5.length = 0;
gdjs.minigame_95paperCode.GDtext_95dryerObjects1.length = 0;
gdjs.minigame_95paperCode.GDtext_95dryerObjects2.length = 0;
gdjs.minigame_95paperCode.GDtext_95dryerObjects3.length = 0;
gdjs.minigame_95paperCode.GDtext_95dryerObjects4.length = 0;
gdjs.minigame_95paperCode.GDtext_95dryerObjects5.length = 0;
gdjs.minigame_95paperCode.GDUI_95timerObjects1.length = 0;
gdjs.minigame_95paperCode.GDUI_95timerObjects2.length = 0;
gdjs.minigame_95paperCode.GDUI_95timerObjects3.length = 0;
gdjs.minigame_95paperCode.GDUI_95timerObjects4.length = 0;
gdjs.minigame_95paperCode.GDUI_95timerObjects5.length = 0;
gdjs.minigame_95paperCode.GDbroken_95leverObjects1.length = 0;
gdjs.minigame_95paperCode.GDbroken_95leverObjects2.length = 0;
gdjs.minigame_95paperCode.GDbroken_95leverObjects3.length = 0;
gdjs.minigame_95paperCode.GDbroken_95leverObjects4.length = 0;
gdjs.minigame_95paperCode.GDbroken_95leverObjects5.length = 0;
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects1.length = 0;
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects2.length = 0;
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects3.length = 0;
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects4.length = 0;
gdjs.minigame_95paperCode.GDcontrol_95mouseObjects5.length = 0;
gdjs.minigame_95paperCode.GDsign_95fallenObjects1.length = 0;
gdjs.minigame_95paperCode.GDsign_95fallenObjects2.length = 0;
gdjs.minigame_95paperCode.GDsign_95fallenObjects3.length = 0;
gdjs.minigame_95paperCode.GDsign_95fallenObjects4.length = 0;
gdjs.minigame_95paperCode.GDsign_95fallenObjects5.length = 0;
gdjs.minigame_95paperCode.GDUI_95livesObjects1.length = 0;
gdjs.minigame_95paperCode.GDUI_95livesObjects2.length = 0;
gdjs.minigame_95paperCode.GDUI_95livesObjects3.length = 0;
gdjs.minigame_95paperCode.GDUI_95livesObjects4.length = 0;
gdjs.minigame_95paperCode.GDUI_95livesObjects5.length = 0;

gdjs.minigame_95paperCode.eventsList16(runtimeScene);
return;

}

gdjs['minigame_95paperCode'] = gdjs.minigame_95paperCode;
