gdjs.minigame_95baseballCode = {};
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects1= [];
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects2= [];
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects3= [];
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects4= [];
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects5= [];
gdjs.minigame_95baseballCode.GDbatObjects1= [];
gdjs.minigame_95baseballCode.GDbatObjects2= [];
gdjs.minigame_95baseballCode.GDbatObjects3= [];
gdjs.minigame_95baseballCode.GDbatObjects4= [];
gdjs.minigame_95baseballCode.GDbatObjects5= [];
gdjs.minigame_95baseballCode.GDNewSpriteObjects1= [];
gdjs.minigame_95baseballCode.GDNewSpriteObjects2= [];
gdjs.minigame_95baseballCode.GDNewSpriteObjects3= [];
gdjs.minigame_95baseballCode.GDNewSpriteObjects4= [];
gdjs.minigame_95baseballCode.GDNewSpriteObjects5= [];
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects1= [];
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2= [];
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3= [];
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4= [];
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects5= [];
gdjs.minigame_95baseballCode.GDMochiObjects1= [];
gdjs.minigame_95baseballCode.GDMochiObjects2= [];
gdjs.minigame_95baseballCode.GDMochiObjects3= [];
gdjs.minigame_95baseballCode.GDMochiObjects4= [];
gdjs.minigame_95baseballCode.GDMochiObjects5= [];
gdjs.minigame_95baseballCode.GDbaseballObjects1= [];
gdjs.minigame_95baseballCode.GDbaseballObjects2= [];
gdjs.minigame_95baseballCode.GDbaseballObjects3= [];
gdjs.minigame_95baseballCode.GDbaseballObjects4= [];
gdjs.minigame_95baseballCode.GDbaseballObjects5= [];
gdjs.minigame_95baseballCode.GDbubble_95gumObjects1= [];
gdjs.minigame_95baseballCode.GDbubble_95gumObjects2= [];
gdjs.minigame_95baseballCode.GDbubble_95gumObjects3= [];
gdjs.minigame_95baseballCode.GDbubble_95gumObjects4= [];
gdjs.minigame_95baseballCode.GDbubble_95gumObjects5= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects1= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects3= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects4= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects5= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects1= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects3= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects4= [];
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects5= [];
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects1= [];
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects2= [];
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects3= [];
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects4= [];
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects5= [];
gdjs.minigame_95baseballCode.GDvictory_95ballObjects1= [];
gdjs.minigame_95baseballCode.GDvictory_95ballObjects2= [];
gdjs.minigame_95baseballCode.GDvictory_95ballObjects3= [];
gdjs.minigame_95baseballCode.GDvictory_95ballObjects4= [];
gdjs.minigame_95baseballCode.GDvictory_95ballObjects5= [];
gdjs.minigame_95baseballCode.GDvictory_95crackObjects1= [];
gdjs.minigame_95baseballCode.GDvictory_95crackObjects2= [];
gdjs.minigame_95baseballCode.GDvictory_95crackObjects3= [];
gdjs.minigame_95baseballCode.GDvictory_95crackObjects4= [];
gdjs.minigame_95baseballCode.GDvictory_95crackObjects5= [];
gdjs.minigame_95baseballCode.GDUI_95livesObjects1= [];
gdjs.minigame_95baseballCode.GDUI_95livesObjects2= [];
gdjs.minigame_95baseballCode.GDUI_95livesObjects3= [];
gdjs.minigame_95baseballCode.GDUI_95livesObjects4= [];
gdjs.minigame_95baseballCode.GDUI_95livesObjects5= [];

gdjs.minigame_95baseballCode.conditionTrue_0 = {val:false};
gdjs.minigame_95baseballCode.condition0IsTrue_0 = {val:false};
gdjs.minigame_95baseballCode.condition1IsTrue_0 = {val:false};
gdjs.minigame_95baseballCode.condition2IsTrue_0 = {val:false};
gdjs.minigame_95baseballCode.condition3IsTrue_0 = {val:false};
gdjs.minigame_95baseballCode.conditionTrue_1 = {val:false};
gdjs.minigame_95baseballCode.condition0IsTrue_1 = {val:false};
gdjs.minigame_95baseballCode.condition1IsTrue_1 = {val:false};
gdjs.minigame_95baseballCode.condition2IsTrue_1 = {val:false};
gdjs.minigame_95baseballCode.condition3IsTrue_1 = {val:false};


gdjs.minigame_95baseballCode.eventsList0 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "vanilla";
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "strawberry";
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "blueberry";
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "banana";
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", true);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", false);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)) == "kiwi";
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "strawberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "blueberry", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "banana", false);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "kiwi", true);
}}

}


};gdjs.minigame_95baseballCode.eventsList1 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 5;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2 */
/* Reuse gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2[i].setOpacity(255);
}
}}

}


};gdjs.minigame_95baseballCode.eventsList2 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UI_lives"), gdjs.minigame_95baseballCode.GDUI_95livesObjects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_0"), gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("control_space_1"), gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "minigame");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDUI_95livesObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDUI_95livesObjects2[i].setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) * 32);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2[i].setOpacity(0);
}
}
{ //Subevents
gdjs.minigame_95baseballCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "minigame") >= 2;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("control_space_0"), gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects1);
gdjs.copyArray(runtimeScene.getObjects("control_space_1"), gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects1);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects1.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects1[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects1.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects1[i].getBehavior("Tween").addObjectOpacityTween("fade", 0, "easeOutQuad", 2000, false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbubble_9595gumObjects3Objects = Hashtable.newFrom({"bubble_gum": gdjs.minigame_95baseballCode.GDbubble_95gumObjects3});
gdjs.minigame_95baseballCode.eventsList3 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 0;
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 3;
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 3;
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 6;
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, 1));
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 6;
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) <= 9;
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 2));
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) > 9;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 5));
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects4});
gdjs.minigame_95baseballCode.eventsList4 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13430300);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2, gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4);

gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointX("spawn_ball")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointY("spawn_ball")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(0, 300), "linear", gdjs.randomInRange(2000, 4000), false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getBehavior("Tween").addObjectPositionTween("softball0", 400, 800, "easeInQuad", 200, false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects4});
gdjs.minigame_95baseballCode.eventsList5 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13433436);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2, gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4);

gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointX("spawn_ball")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointY("spawn_ball")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(0, 2000), "linear", gdjs.randomInRange(2000, 4000), false);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getBehavior("Tween").addObjectPositionTween("fastball0", 400, 800, "linear", 800 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 500), false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects4});
gdjs.minigame_95baseballCode.eventsList6 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13436900);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2, gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4);

gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointX("spawn_ball")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointY("spawn_ball")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(0, 3600), "linear", 2000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("curveball0", 400, 260, "linear", 300, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getY() >= 230 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13439892);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("curveball0");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("curveball1", 550, 260, "linear", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getX() >= 520 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13441900);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("curveball1");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("curveball2", 550, 200, "linear", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getY() <= 220 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13444124);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("curveball2");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 3 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("curveball3", 400, 200, "linear", 100, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 3 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getX() <= 420 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13446116);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("curveball3");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariables().getFromIndex(0)) == 4 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects3[k] = gdjs.minigame_95baseballCode.GDbaseballObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects3.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects3 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getBehavior("Tween").addObjectPositionTween("curveball4", 400, 800, "linear", 350, false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects4});
gdjs.minigame_95baseballCode.eventsList7 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13448460);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2, gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4);

gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointX("spawn_ball")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointY("spawn_ball")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(0, 3600), "linear", 2000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("trickball0", 400, 260, "linear", 750, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getY() >= 200 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13451620);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("trickball0");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects3[k] = gdjs.minigame_95baseballCode.GDbaseballObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects3.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects3 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getBehavior("Tween").addObjectPositionTween("trickball1", 400, 900, "linear", 500 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 300), false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects4});
gdjs.minigame_95baseballCode.eventsList8 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13454340);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2, gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4);

gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects4Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointX("spawn_ball")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4[0].getPointY("spawn_ball")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(0, 3600), "linear", 2000, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("shamanball0", 400, 260, "linear", 750, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getY() >= 230 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13457500);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("shamanball0");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("shamanball1", 550, 260, "easeInExpo", 25, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getX() >= 520 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13459532);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("shamanball1");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("shamanball2", 550, 200, "easeInExpo", 25, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getY() <= 220 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13461764);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("shamanball2");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 3 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("shamanball3", -(400), 200, "easeInExpo", 25, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 3 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getX() <= -(300) ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13463780);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("shamanball3");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 4 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13464932);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].setPosition(850,320);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 5 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").addObjectPositionTween("shamanball4", 400, 200, "easeInExpo", 25, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects4);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)) == 5 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects4.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getX() <= 460 ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects4[k] = gdjs.minigame_95baseballCode.GDbaseballObjects4[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = k;}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13466812);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects4 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getBehavior("Tween").removeTween("shamanball4");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects4.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects4[i].returnVariable(gdjs.minigame_95baseballCode.GDbaseballObjects4[i].getVariables().getFromIndex(0)).setNumber(6);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariableNumber(gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getVariables().getFromIndex(0)) == 6 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects3[k] = gdjs.minigame_95baseballCode.GDbaseballObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects3.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects3 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getBehavior("Tween").addObjectPositionTween("shamanball5", 400, 800, "easeInExpo", 40 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 15), false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects3Objects = Hashtable.newFrom({"bat": gdjs.minigame_95baseballCode.GDbatObjects3});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects3Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects3});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects3Objects = Hashtable.newFrom({"bat": gdjs.minigame_95baseballCode.GDbatObjects3});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects3Objects = Hashtable.newFrom({"baseball": gdjs.minigame_95baseballCode.GDbaseballObjects3});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDvictory_9595ballObjects3Objects = Hashtable.newFrom({"victory_ball": gdjs.minigame_95baseballCode.GDvictory_95ballObjects3});
gdjs.minigame_95baseballCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects3 */
/* Reuse gdjs.minigame_95baseballCode.GDbatObjects3 */

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects3Objects, gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects3Objects, false, runtimeScene, false);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDvictory_9595ballObjects3Objects, 390, 490, "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[i].getBehavior("Tween").addObjectPositionTween("victory", gdjs.randomInRange(200, 600), gdjs.randomInRange(50, 300), "linear", 1350, false);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[i].getBehavior("Tween").addObjectScaleTween("victory_scale", 3.0, 3.0, "linear", 1350, false, false);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[i].getBehavior("Tween").addObjectAngleTween("ball_rotation", gdjs.randomInRange(1200, 2400), "linear", 2000, false);
}
}}

}


};gdjs.minigame_95baseballCode.mapOfEmptyGDvictory_95ballObjects = Hashtable.newFrom({"victory_ball": []});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDvictory_9595crackObjects3Objects = Hashtable.newFrom({"victory_crack": gdjs.minigame_95baseballCode.GDvictory_95crackObjects3});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects2Objects = Hashtable.newFrom({"bat": gdjs.minigame_95baseballCode.GDbatObjects2});
gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDMochiObjects2Objects = Hashtable.newFrom({"Mochi": gdjs.minigame_95baseballCode.GDMochiObjects2});
gdjs.minigame_95baseballCode.eventsList10 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13424772);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "throw0.wav", false, 100, 1);
}
{ //Subevents
gdjs.minigame_95baseballCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 0;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 1;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 2;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 3;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 4;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 5;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95baseballCode.GDMochiObjects3);
gdjs.copyArray(runtimeScene.getObjects("text_highFive"), gdjs.minigame_95baseballCode.GDtext_95highFiveObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochiObjects3[i].getBehavior("Tween").addObjectPositionTween("Mochiball0", 360, 700, "linear", 1000 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 10) * 500), false);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDtext_95highFiveObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDtext_95highFiveObjects3[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochiObjects3[i].setAnimation(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);
gdjs.copyArray(runtimeScene.getObjects("bat"), gdjs.minigame_95baseballCode.GDbatObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects3Objects, gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbaseballObjects3Objects, false, runtimeScene, false);
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13470988);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbaseballObjects3 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbaseballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbaseballObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ball_hit.wav", false, 100, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "home_run0.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("home_runs").add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "victory_timer");
}
{ //Subevents
gdjs.minigame_95baseballCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95baseballCode.GDMochiObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDMochiObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDMochiObjects3[i].getY() >= 600 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDMochiObjects3[k] = gdjs.minigame_95baseballCode.GDMochiObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDMochiObjects3.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13475644);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "victory_timer");
}{gdjs.evtTools.sound.playSound(runtimeScene, "yeehaw.wav", false, 100, 1);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition2IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfEmptyGDvictory_95ballObjects) > 0;
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "victory_timer") > 1.5;
}if ( gdjs.minigame_95baseballCode.condition1IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition2IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13476908);
}
}}
}
if (gdjs.minigame_95baseballCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("victory_ball"), gdjs.minigame_95baseballCode.GDvictory_95ballObjects3);
gdjs.minigame_95baseballCode.GDvictory_95crackObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDvictory_9595crackObjects3Objects, (( gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[0].getPointX("Center")), (( gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[0].getPointY("Center")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95crackObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95crackObjects3[i].setScale(4.0);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95crackObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95crackObjects3[i].rotateTowardAngle(gdjs.randomInRange(0, 359), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDvictory_95ballObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "glassBreak.wav", false, 100, 1);
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "victory_timer") > 3;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("baseball"), gdjs.minigame_95baseballCode.GDbaseballObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbaseballObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbaseballObjects3[i].getY() >= 600 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbaseballObjects3[k] = gdjs.minigame_95baseballCode.GDbaseballObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbaseballObjects3.length = k;}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13479428);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ball_miss.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95baseballCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("bat"), gdjs.minigame_95baseballCode.GDbatObjects2);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbatObjects2Objects, gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDMochiObjects2Objects, false, runtimeScene, false);
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13481156);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "oopsie.wav", false, 100, 1);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "transition", false);
}}

}


};gdjs.minigame_95baseballCode.eventsList11 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13417900);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi_Pitcher"), gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3);
gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.minigame_95baseballCode.mapOfGDgdjs_46minigame_9595baseballCode_46GDbubble_9595gumObjects3Objects, (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[0].getPointX("blow_bubble_gum")), (( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length === 0 ) ? 0 :gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[0].getPointY("blow_bubble_gum")), "");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbubble_95gumObjects3[i].setScale(0.1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi_Pitcher"), gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[i].getVariableBoolean(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[k] = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("bubble_gum"), gdjs.minigame_95baseballCode.GDbubble_95gumObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbubble_95gumObjects3[i].getBehavior("Tween").addObjectScaleTween("inflate", 1, 1, "linear", 1000 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 1000), false, true);
}
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "play_ball") >= 6 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 6);
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition1IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13421260);
}
}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95baseballCode.GDMochiObjects3);
gdjs.copyArray(runtimeScene.getObjects("bubble_gum"), gdjs.minigame_95baseballCode.GDbubble_95gumObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbubble_95gumObjects3[i].getBehavior("Tween").removeTween("inflate");
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbubble_95gumObjects3[i].setLayer("Hidden");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "bubble_pop.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochiObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochiObjects3[i].setAnimation(2);
}
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "play_ball") >= 8 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 8);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi_Pitcher"), gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3);
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[i].setVariableBoolean(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mochi_Pitcher"), gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2[i].getVariableBoolean(gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2[k] = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95baseballCode.eventsList12 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
{gdjs.minigame_95baseballCode.conditionTrue_1 = gdjs.minigame_95baseballCode.condition0IsTrue_0;
gdjs.minigame_95baseballCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13484516);
}
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.minigame_95baseballCode.GDbatObjects1, gdjs.minigame_95baseballCode.GDbatObjects2);

{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbatObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbatObjects2[i].resetTimer("swing_time");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "swing.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.minigame_95baseballCode.GDbatObjects1, gdjs.minigame_95baseballCode.GDbatObjects2);


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbatObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbatObjects2[i].getTimerElapsedTimeInSecondsOrNaN("swing_time") < 0.35 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbatObjects2[k] = gdjs.minigame_95baseballCode.GDbatObjects2[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbatObjects2.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbatObjects2 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbatObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbatObjects2[i].rotate(-(1000), runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.minigame_95baseballCode.GDbatObjects1, gdjs.minigame_95baseballCode.GDbatObjects2);


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbatObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbatObjects2[i].getTimerElapsedTimeInSecondsOrNaN("swing_time") >= 0.35 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbatObjects2[k] = gdjs.minigame_95baseballCode.GDbatObjects2[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbatObjects2.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbatObjects2 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbatObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbatObjects2[i].setAngle(90);
}
}}

}


{

/* Reuse gdjs.minigame_95baseballCode.GDbatObjects1 */

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbatObjects1.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbatObjects1[i].getTimerElapsedTimeInSecondsOrNaN("swing_time") >= 0.9 ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbatObjects1[k] = gdjs.minigame_95baseballCode.GDbatObjects1[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbatObjects1.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbatObjects1 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbatObjects1.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbatObjects1[i].setVariableBoolean(gdjs.minigame_95baseballCode.GDbatObjects1[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.minigame_95baseballCode.eventsList13 = function(runtimeScene) {

{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mochi"), gdjs.minigame_95baseballCode.GDMochiObjects2);
gdjs.copyArray(runtimeScene.getObjects("Mochi_Pitcher"), gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2);
gdjs.copyArray(runtimeScene.getObjects("text_highFive"), gdjs.minigame_95baseballCode.GDtext_95highFiveObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "play_ball");
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDMochiObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDMochiObjects2[i].flipX(true);
}
}{for(var i = 0, len = gdjs.minigame_95baseballCode.GDtext_95highFiveObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDtext_95highFiveObjects2[i].setOpacity(0);
}
}}

}


{



}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "play_ball") >= 3 - ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 12) * 3);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("bat"), gdjs.minigame_95baseballCode.GDbatObjects2);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
gdjs.minigame_95baseballCode.condition1IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.minigame_95baseballCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbatObjects2.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbatObjects2[i].getVariableBoolean(gdjs.minigame_95baseballCode.GDbatObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.minigame_95baseballCode.condition1IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbatObjects2[k] = gdjs.minigame_95baseballCode.GDbatObjects2[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbatObjects2.length = k;}}
if (gdjs.minigame_95baseballCode.condition1IsTrue_0.val) {
/* Reuse gdjs.minigame_95baseballCode.GDbatObjects2 */
{for(var i = 0, len = gdjs.minigame_95baseballCode.GDbatObjects2.length ;i < len;++i) {
    gdjs.minigame_95baseballCode.GDbatObjects2[i].setVariableBoolean(gdjs.minigame_95baseballCode.GDbatObjects2[i].getVariables().getFromIndex(0), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bat"), gdjs.minigame_95baseballCode.GDbatObjects1);

gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.minigame_95baseballCode.GDbatObjects1.length;i<l;++i) {
    if ( gdjs.minigame_95baseballCode.GDbatObjects1[i].getVariableBoolean(gdjs.minigame_95baseballCode.GDbatObjects1[i].getVariables().getFromIndex(0), false) ) {
        gdjs.minigame_95baseballCode.condition0IsTrue_0.val = true;
        gdjs.minigame_95baseballCode.GDbatObjects1[k] = gdjs.minigame_95baseballCode.GDbatObjects1[i];
        ++k;
    }
}
gdjs.minigame_95baseballCode.GDbatObjects1.length = k;}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.minigame_95baseballCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.minigame_95baseballCode.eventsList14 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}}

}


{


gdjs.minigame_95baseballCode.condition0IsTrue_0.val = false;
{
gdjs.minigame_95baseballCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "time_played") >= 1;
}if (gdjs.minigame_95baseballCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "time_played");
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("time_played").add(1);
}}

}


};gdjs.minigame_95baseballCode.eventsList15 = function(runtimeScene) {

{


gdjs.minigame_95baseballCode.eventsList0(runtimeScene);
}


{


gdjs.minigame_95baseballCode.eventsList2(runtimeScene);
}


{


gdjs.minigame_95baseballCode.eventsList13(runtimeScene);
}


{


gdjs.minigame_95baseballCode.eventsList14(runtimeScene);
}


};

gdjs.minigame_95baseballCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.minigame_95baseballCode.GDbkg_95baseballObjects1.length = 0;
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects2.length = 0;
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects3.length = 0;
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects4.length = 0;
gdjs.minigame_95baseballCode.GDbkg_95baseballObjects5.length = 0;
gdjs.minigame_95baseballCode.GDbatObjects1.length = 0;
gdjs.minigame_95baseballCode.GDbatObjects2.length = 0;
gdjs.minigame_95baseballCode.GDbatObjects3.length = 0;
gdjs.minigame_95baseballCode.GDbatObjects4.length = 0;
gdjs.minigame_95baseballCode.GDbatObjects5.length = 0;
gdjs.minigame_95baseballCode.GDNewSpriteObjects1.length = 0;
gdjs.minigame_95baseballCode.GDNewSpriteObjects2.length = 0;
gdjs.minigame_95baseballCode.GDNewSpriteObjects3.length = 0;
gdjs.minigame_95baseballCode.GDNewSpriteObjects4.length = 0;
gdjs.minigame_95baseballCode.GDNewSpriteObjects5.length = 0;
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects1.length = 0;
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects2.length = 0;
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects3.length = 0;
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects4.length = 0;
gdjs.minigame_95baseballCode.GDMochi_95PitcherObjects5.length = 0;
gdjs.minigame_95baseballCode.GDMochiObjects1.length = 0;
gdjs.minigame_95baseballCode.GDMochiObjects2.length = 0;
gdjs.minigame_95baseballCode.GDMochiObjects3.length = 0;
gdjs.minigame_95baseballCode.GDMochiObjects4.length = 0;
gdjs.minigame_95baseballCode.GDMochiObjects5.length = 0;
gdjs.minigame_95baseballCode.GDbaseballObjects1.length = 0;
gdjs.minigame_95baseballCode.GDbaseballObjects2.length = 0;
gdjs.minigame_95baseballCode.GDbaseballObjects3.length = 0;
gdjs.minigame_95baseballCode.GDbaseballObjects4.length = 0;
gdjs.minigame_95baseballCode.GDbaseballObjects5.length = 0;
gdjs.minigame_95baseballCode.GDbubble_95gumObjects1.length = 0;
gdjs.minigame_95baseballCode.GDbubble_95gumObjects2.length = 0;
gdjs.minigame_95baseballCode.GDbubble_95gumObjects3.length = 0;
gdjs.minigame_95baseballCode.GDbubble_95gumObjects4.length = 0;
gdjs.minigame_95baseballCode.GDbubble_95gumObjects5.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects1.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects2.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects3.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects4.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_950Objects5.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects1.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects2.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects3.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects4.length = 0;
gdjs.minigame_95baseballCode.GDcontrol_95space_951Objects5.length = 0;
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects1.length = 0;
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects2.length = 0;
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects3.length = 0;
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects4.length = 0;
gdjs.minigame_95baseballCode.GDtext_95highFiveObjects5.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95ballObjects1.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95ballObjects2.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95ballObjects3.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95ballObjects4.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95ballObjects5.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95crackObjects1.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95crackObjects2.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95crackObjects3.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95crackObjects4.length = 0;
gdjs.minigame_95baseballCode.GDvictory_95crackObjects5.length = 0;
gdjs.minigame_95baseballCode.GDUI_95livesObjects1.length = 0;
gdjs.minigame_95baseballCode.GDUI_95livesObjects2.length = 0;
gdjs.minigame_95baseballCode.GDUI_95livesObjects3.length = 0;
gdjs.minigame_95baseballCode.GDUI_95livesObjects4.length = 0;
gdjs.minigame_95baseballCode.GDUI_95livesObjects5.length = 0;

gdjs.minigame_95baseballCode.eventsList15(runtimeScene);
return;

}

gdjs['minigame_95baseballCode'] = gdjs.minigame_95baseballCode;
